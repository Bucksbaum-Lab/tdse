cd Gaussian_1D;     qm_run;    cd ..;
cd Gaussian_2D;     qm_run;    cd ..;
cd SchroediCat;     qm_run;    cd ..;
