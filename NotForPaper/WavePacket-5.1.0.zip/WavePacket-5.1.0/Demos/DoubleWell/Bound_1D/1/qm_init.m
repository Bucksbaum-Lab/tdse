% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2008-2009 Ulf Lorenz
%               2011 Ulf Lorenz
%
% This file is under public domain. You may modify or incorporate it into other
% works without any restrictions.

function qm_init
global hamilt plots psi space

util.disp ( '*********************' )
util.disp ( 'Double well potential' )
util.disp ( '*********************' )

% Number of (coupled) Schr�dinger equations
hamilt.coupling.n_eqs = 1;

% Spatial discretization
space.dof{1} = grid_fft;                 % using FFT grid
space.dof{1}.mass = 1;                   % mass
space.dof{1}.n_pts = 128;                % Number of grid points
space.dof{1}.x_min = -8.2;               % Lower bound of grid 
space.dof{1}.x_max =  8.2;               % Upper bound of grid

% Hamiltonian operator 
hamilt.eigen.cutoff    = 0.0;            % Cut-off entries of Hamiltonian matrix

hamilt.truncate.min    = -15.0;          % Lower truncation of energy
hamilt.truncate.max    =  85.0;          % Upper truncation of energy

hamilt.pot.handle      = @pot.quartic;   % Double well potential
hamilt.pot.params.v_2  =  -3.0;          % Quadratic constant
hamilt.pot.params.v_4  =  +1.0;          % Quartic  constant

% Select eigen/values/functions
psi.eigen.start        = 0;              % Lower index
psi.eigen.stop         = 25;             % Upper index

% Modify settings for appearance of plots (if desired)
plots.density.type = 'contour';

plots.expect.energies.max = 20;
