% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2008-2009 Ulf Lorenz
%               2011 Ulf Lorenz
%                    Boris Schaefer-Bung
%
% This file is under public domain. You may modify or incorporate it into other
% works without any restrictions.

function qm_init
global hamilt plots psi space time control dim_red

util.disp ( '**********************************' )
util.disp ( 'Asymmetric double well potential  ' )
util.disp ( ' see example 1 in:                ' )
util.disp ( ' B. Schaefer-Bung, C. Hartmann,   ' )
util.disp ( ' B. Schmidt, and Ch. Schuette,    ' )
util.disp ( ' J. Chem. Phys. 135, 014112 (2011)' )
util.disp ( '**********************************' )

% Number of (coupled) Schroedinger equations
hamilt.coupling.n_eqs = 1;

% Spatial discretization
space.dof{1} = grid_fft;                 % using FFT grid
space.dof{1}.mass = 162;                 % I=162 [hbar^2/D], see section IV.B
space.dof{1}.n_pts = 256;                % Number of grid points
space.dof{1}.x_min = -2.0;               % Lower bound of grid 
space.dof{1}.x_max =  2.0;               % Upper bound of grid

% Temporal discretization
time.main.start = 0;                     % Index of initial time step
time.main.stop  = 100;                   % Index of final time step
time.main.delta = 3*pi/(100*0.196);      % Size of time steps 

% Propagator
time.propa.handle = @ket.splitting;      % Operator splitting
time.propa.params.order = 3;             % Symmetrized (Strang) scheme

% Electric field as half-cycle pulse
time.efield.dressed = false;             % Not using dressed state picture
time.efield.shape   = 'recta';           % Rectangular shape of envelope
time.efield.polar   = 0;                 % Polarization angle [rad]
time.efield.delay   = pi/(2*0.196);      % Time delay of pulse center
time.efield.fwhm    = pi/0.196;          % Full width at half maximum
time.efield.ampli   = 7.5;               % u_0=7.5 [D/(e*a_0)] see section IV.B
time.efield.frequ   = 0.196;             % Omega = 0.196 [D/hbar], see section IV.B
time.efield.phase   = 0;                 % Phase

% Hamiltonian operator 
hamilt.eigen.cutoff    =  0.0;           % Cut-off entries of Hamiltonian matrix
hamilt.truncate.min    =  -1.0;          % Lower truncation of energy
hamilt.truncate.max    =   10.0;         % Upper truncation of energy

hamilt.pot.handle      = @pot.quartic;   % Double well potential
hamilt.pot.params.v_0  =   1.0;          % Shift
hamilt.pot.params.v_1  =   0.055;        % Linear constant
hamilt.pot.params.v_2  =  -4.0;          % Quadratic constant
hamilt.pot.params.v_4  =  24.0;          % Quartic  constant

hamilt.dip.handle = @dip.lin;            % Linear dipole moment
hamilt.dip.params.r_0  = 0;              % equilibrium distance
hamilt.dip.params.mu_0 = 0;              % permanent dipole moment@equilibrium distance
hamilt.dip.params.q_0  = 1;              % slope of linear part

% System-bath coupling
hamilt.sbc.handle = @sbc.lin;            % Linear coupling to bath modes (==> qm_lvne)
hamilt.sbc.params.r_0  = 0;              % equilibrium distance
hamilt.sbc.params.chi_0 = 0;             % coupling @ equilibrium distance
hamilt.sbc.params.kappa  = 1;            % slope of linear coupling

% Calculate and save (bound) eigen states (==> qm_bound)
psi.eigen.start        = 0;              % Lower index
psi.eigen.stop         = 20;             % Upper index
psi.save.export        = true;
psi.save.dir           = pwd;
psi.save.file          = 'bound';

% Select ODE solver, parameters, initial state (==> qm_control)
control.ode.solver = @ode45;             % Runge-Kutta
control.ode.reltol = 1e-6;               % Relative error tolerance of solution
          
% Initial density
control.initial.choice = 'thermal';      % thermal = Boltzmann density
control.initial.temperature = 1.0;       % choice of temperature

% Temperature and system-bath coupling
control.lvne.order = 'df';               % ordering vectorized density matrices: diagonals first
control.lvne.temperature = 1.0;          % temperature in atomic units: 315,923.5 K
control.lvne.relax.rate =  0.264386355;  % Gamma_{2->0} should be = 1 [D/hbar]
                                         % set to 0.2644 due to error in ancestor code 
control.lvne.relax.lower = 0;            % Lower state for reference transition
control.lvne.relax.upper = 2;            % Upper state for reference transition
control.lvne.relax.model = 'omega';      % Omega dependent (Andrianov&Saalfrank)

% Define output observables and choose control targets
control.observables={0:2:10 1:2:9 11:20}; 
control.labels={'left well' 'right well' 'delocalized'};
control.targets=1:3; 

% Parameters for balanced truncation
dim_red.Balance.A_stable = 'ssu';        % SSU or EVS method for stabilizing A  
dim_red.Balance.A_shift = 1e-6;          % magnitude of eigenvalue shift
dim_red.Balance.A_split = 1;             % dimension of instable part of A
dim_red.Balance.BN_scale = 3;            % Scaling factor for control fields
dim_red.Balance.acf_couple = true;       % additional control field coupling A and rho/x
dim_red.Balance.method = 'iter';         % ITER or BICG solver for GLYAP
dim_red.Balance.transform = 'srbt';      % SRBT or MRMR balancing transform;
dim_red.Balance.truncate = 'normal';     % normal or confinement truncation

% Parameters for H2 model reduction (Benner/Breiten @ MPI Magdeburg)
dim_red.Reduce.A_stable = 'ssu';         % SSU or EVS method for stabilizing A  
dim_red.Reduce.A_shift = 1e-6;           % magnitude of eigenvalue shift
dim_red.Reduce.A_split = 1;              % dimension of instable part of A
dim_red.Reduce.BN_scale = 3;             % Scaling factor for control fields
dim_red.Reduce.acf_couple = true;        % additional control field coupling A and rho/x
dim_red.Reduce.method = 'iter';          % ITER or BICG solver for BIRKA

% Modify settings for appearance of plots (if desired)
plots.density.type = 'contour';          % Contour plot of Wigner transform
plots.density.export.on = true;
plots.expect.export.on = true;
plots.expect.population.min = 0.26;
plots.expect.population.max = 0.42;

plots.expect.energies.max = 2;           % Range of energy plot


