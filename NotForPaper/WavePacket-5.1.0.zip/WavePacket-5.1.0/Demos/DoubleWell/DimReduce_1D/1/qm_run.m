aux.qm_BTversusH2 (36, [20 10 5], [20 10 05], 0);
saveas(36, 'comparison.jpg');
