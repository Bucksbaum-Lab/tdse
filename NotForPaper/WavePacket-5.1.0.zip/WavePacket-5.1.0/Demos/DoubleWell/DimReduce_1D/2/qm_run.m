aux.qm_BTversusH2 (37, [40 29 21], [40 29 21], 0);
saveas(37, 'comparison.jpg');
