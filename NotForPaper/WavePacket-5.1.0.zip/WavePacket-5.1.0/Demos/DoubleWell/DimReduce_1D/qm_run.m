cd 1; qm_run; cd ..;
cd 2; qm_run; cd ..;
cd 3; qm_run; cd ..;