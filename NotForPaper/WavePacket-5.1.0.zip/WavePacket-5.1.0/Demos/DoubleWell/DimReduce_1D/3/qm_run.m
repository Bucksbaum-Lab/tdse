aux.qm_BTversusH2 (38, [180 110 90], [180 110 90], 0);
saveas(38, 'comparison.jpg');