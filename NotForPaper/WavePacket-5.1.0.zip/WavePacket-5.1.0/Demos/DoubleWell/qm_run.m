cd Bound_1D;     qm_run;    cd ..;
cd Gaussian_1D;  qm_run;    cd ..;
cd DimReduce_1D; qm_run;    cd ..;
