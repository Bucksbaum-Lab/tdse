cd 1D;  qm_run;    cd ..;
