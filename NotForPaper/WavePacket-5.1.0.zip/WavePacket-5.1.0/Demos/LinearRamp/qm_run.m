cd Gaussian_1D;     qm_run;    cd ..;
