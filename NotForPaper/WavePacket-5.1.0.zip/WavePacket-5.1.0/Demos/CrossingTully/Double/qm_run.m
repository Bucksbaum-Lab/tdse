cd 1;   qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
cd 2;   qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
cd 3;   qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
