cd 1;   qm_run;    cd ..;
% The optimal control demo needs to be updated
%cd 2;   qm_run;    cd ..;
cd 3;   qm_run;    cd ..;
