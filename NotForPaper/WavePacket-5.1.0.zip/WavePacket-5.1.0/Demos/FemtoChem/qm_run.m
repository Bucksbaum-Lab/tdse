cd HOD;             qm_run;    cd ..;
cd Interferometry;  qm_run;    cd ..;
