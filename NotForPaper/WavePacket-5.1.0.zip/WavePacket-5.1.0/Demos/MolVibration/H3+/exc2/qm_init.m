% Copyright (C) 2008 Ulf Lorenz
%
% This file is under public domain. You may modify or incorporate it into other
% works without any restrictions.

function qm_init
global hamilt plots psi space time

conv_amu_au = 1822.888;             % from amu to a.u.

mass_H = 1.00782503207 * conv_amu_au;


util.disp( '***********************************************' )
util.disp( 'Testing case fore triatomic Jacobi Hamiltonian ' )
util.disp( 'Second excited state of H3+                    ' )
util.disp( '***********************************************' )


%% One Schroedinger equations
hamilt.coupling.n_eqs = 1;

%% Grid parameter
% First coordinate: H-H distance
space.dof{1}       = grid_fft;      % equally spaced FFT grid
space.dof{1}.label = 'H-H';         % label
space.dof{1}.mass  = mass_H/2;      % reduced mass of coordinate
space.dof{1}.x_min = 0.9;           % minimum grid point
space.dof{1}.x_max = 4.5;           % maximum grid point
space.dof{1}.n_pts = 64;            % number of grid points

% Second coordinate: Distance between H and H2 center (diss. coordinate)
space.dof{2}       = grid_fft;      % equally spaced FFT grid
space.dof{2}.label = 'H-H2';        % label
space.dof{2}.mass  = 2/3 * mass_H;  % reduced mass of coordinate
space.dof{2}.x_min = 0.7;           % minimum grid point
space.dof{2}.x_max = 4;             % maximum grid point
space.dof{2}.n_pts = 64;            % number of grid points

% Third coordinate: angle (/cos of angle) between the former two
% Note that we use kin_jacobi for the kinetic energy calculation
space.dof{3}       = grid_legendre; % Legendre/Spherical harmonics expansion of cos theta
space.dof{3}.label = 'c';           % label
space.dof{3}.mass  = 1;             % unused
space.dof{3}.m_0   = 0;             % minor quantum number of spherical harmonic
space.dof{3}.R_0   = 1;             % unused
space.dof{3}.l_max = 40;            % maximum quantum number

% Temporal discretization
time.main.start = 00;               % Index of initial time step
time.main.stop  = 10;               % Index of final time step

time.main.delta = 5*41.43;          % Size of big time step: 5fs
time.sub.n      = 1;                % Number of sub steps per time step

% Propagator
time.propa.handle = @my_relax_2;        % Chebyshev expansion in imaginary time
time.propa.params.order = 0;            % auto-determine number of polynomials
time.propa.params.precision = 1e-10;    % requested precision of the propagation

% Hamiltonian operator 
hamilt.truncate.min = 0;            % Lower truncation of energy
hamilt.truncate.max = +1;           % Upper truncation of energy

hamilt.pot.handle     = @pot.H3plus;% Use H3+ potential
hamilt.pot.params.c_dof = 3;        % 3rd DOF is angular coordinate

hamilt.kin{1} = kin_jacobi;         % Use kin_jacobi for the angular coordinate
hamilt.kin{1}.dof_r = 1;            % first DOF is bonding distance
hamilt.kin{1}.dof_R = 2;            % second DOF is dissociative one
hamilt.kin{1}.dof_c = 3;            % third DOF is cos(angle)
hamilt.kin{1}.mass_r = mass_H/2;    % reduced mass of the bonding DOF
hamilt.kin{1}.mass_R = 2/3 * mass_H;% reduced mass of the dissociative DOF

% Initial wave function is a Gaussian. It is located at the
% equilibrium positions of the potential. The angular coordinate
% is shifted so that we avoid a symmetric setup
psi.init.corr.handle = @wav.gauss;
psi.init.corr.pos_0  = [1.6 1.4 cosd(80)];
psi.init.corr.mom_0  = [0 0 0];
psi.init.corr.width  = [0.6 0.6 0.2];
psi.init.corr.factor = [1 1 1];


% We do not have any reasonable plotting facilities, so turn it off.
plots.density.on = false;
plots.expect.on  = false;
