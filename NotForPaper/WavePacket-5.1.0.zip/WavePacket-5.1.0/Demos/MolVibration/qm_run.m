cd Cl-NH3;      qm_run;    cd ..;
cd HF;          qm_run;    cd ..;
cd OH;          qm_run;    cd ..;
cd H3+;         qm_run;    cd ..;
