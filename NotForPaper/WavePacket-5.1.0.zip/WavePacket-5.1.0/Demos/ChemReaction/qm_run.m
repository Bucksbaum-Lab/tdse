cd D2F;     qm_run;    cd ..;
