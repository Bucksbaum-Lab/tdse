cd 1;   qm_setup('qm_bound'); qm_init(); qm_bound(); qm_cleanup();   cd ..;
