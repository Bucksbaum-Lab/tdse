cd Bound_1D;    qm_run;    cd ..;
cd Bound_2D;    qm_run;    cd ..;
cd Eigen_2D;    qm_run;    cd ..;
cd Gaussian_1D; qm_run;    cd ..;
cd Gaussian_2D; qm_run;    cd ..;
cd Gaussian_3D; qm_run;    cd ..;
