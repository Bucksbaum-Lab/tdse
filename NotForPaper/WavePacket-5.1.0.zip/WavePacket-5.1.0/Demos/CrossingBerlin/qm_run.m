cd Double;  qm_run;    cd ..;
cd Single;  qm_run;    cd ..;
