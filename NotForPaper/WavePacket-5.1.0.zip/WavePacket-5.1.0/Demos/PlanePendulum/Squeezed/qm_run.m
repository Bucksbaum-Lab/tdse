cd 'V000';   qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
cd 'V001';   qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
cd 'V010';   qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
