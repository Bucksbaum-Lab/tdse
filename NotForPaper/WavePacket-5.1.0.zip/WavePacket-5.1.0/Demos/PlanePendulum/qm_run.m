cd 'Coherent';    qm_run;    cd ..;
cd 'Double';      qm_run;    cd ..;
cd 'Squeezed';    qm_run;    cd ..;
cd 'Stationary';  qm_run;    cd ..;
