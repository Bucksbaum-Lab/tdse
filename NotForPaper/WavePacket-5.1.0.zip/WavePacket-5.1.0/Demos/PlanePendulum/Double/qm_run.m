cd 'Even';   qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
cd 'Odd';    qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
cd 'Local';  qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ..;
