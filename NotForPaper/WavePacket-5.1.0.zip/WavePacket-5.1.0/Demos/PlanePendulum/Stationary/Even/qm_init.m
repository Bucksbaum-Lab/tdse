% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2008 Ulf Lorenz
%               2008-2009 Burkhard Schmidt
%               2011 Ulf Lorenz
%
% This file is under public domain. You may modify or incorporate it into other
% works without any restrictions.

function qm_init
global hamilt plots psi space time

util.disp ( '***************************************' )
util.disp ( 'Eigenstates of plane quantum pendulum  ' )
util.disp ( '***************************************' )

% Number of (coupled) Schr�dinger equations
hamilt.coupling.n_eqs = 1;

% Spatial discretization
space.dof{1}       = grid_fft;           % using fft grid
space.dof{1}.mass  = 1;                  % mass
space.dof{1}.n_pts = 192;                % Number of grid points
space.dof{1}.x_min = 0;                  % Lower bound of grid 
space.dof{1}.x_max = 2*pi;               % Upper bound of grid
space.prj.handle   = @prj.cosine;        % Degree of alignment

% Hamiltonian operator 
hamilt.truncate.min  = 000;              % Lower truncation of energy
hamilt.truncate.max  = 300;              % Upper truncation of energy

hamilt.pot.handle    = @pot.pendulum;    % Intramolecular torsion
hamilt.pot.params.barrier  = 100;        % Barrier height
hamilt.pot.params.multiple  = 1;         % Multiplicity

% Fourier grid Hamiltonian
hamilt.eigen.cutoff    = 0.0;            % Cut-off entries of Hamiltonian matrix
hamilt.eigen.symmetry  = 'g';            % Even paarity states

% Select eigen/values/functions
psi.eigen.start        =  0;             % Lower index
psi.eigen.stop         = 20;             % Upper index

% Modify settings for appearance of plots (if desired)
plots.density.type        = 'polar';

plots.expect.energies.max = 300;

plots.density.export.on = true;
plots.expect.export.on = true;
