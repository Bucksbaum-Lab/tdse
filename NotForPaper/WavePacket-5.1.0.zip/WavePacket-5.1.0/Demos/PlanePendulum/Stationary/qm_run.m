cd 'Even';   qm_setup('qm_bound'); qm_init(); qm_bound(); qm_cleanup();   cd ..;
cd 'Odd';    qm_setup('qm_bound'); qm_init(); qm_bound(); qm_cleanup();   cd ..;
