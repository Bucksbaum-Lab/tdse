cd HCl+;    qm_run;    cd ..;
cd OH;      qm_run;    cd ..;
cd Pyrazine;      qm_run;    cd ..;
cd Retinal;      qm_run;    cd ..;
