cd 0.5fs/BareState;     qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ../..;
cd 0.5fs/Floquet07;     qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ../..;
cd 1.0fs/BareState;     qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ../..;
cd 1.0fs/Floquet07;     qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ../..;
cd 3.0fs/BareState;     qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ../..;
cd 3.0fs/Floquet07;     qm_setup('qm_propa'); qm_init(); qm_propa(); qm_cleanup();   cd ../..;
