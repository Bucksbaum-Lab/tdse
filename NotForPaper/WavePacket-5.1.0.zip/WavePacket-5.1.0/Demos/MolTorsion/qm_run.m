cd Fulvene;     qm_run;    cd ..;
cd C9A;         qm_run;    cd ..;
