% Copyright (C) 2008-2009 Ulf Lorenz
%               2011 Ulf Lorenz
%
% This file is under public domain. You may modify or incorporate it into other
% works without any restrictions.

function qm_init
global hamilt plots psi space

util.disp ( '***************************************' )
util.disp ( 'Pendular States for \Delta \omega = 400' )
util.disp ( '***************************************' )


% Note that the paper uses normalised units. We choose the rotational
% constant B = \hbar^2/(2mR^2) to be one a.u., so that the time units in
% the paper are the same numbers as the time units in a.u. used in the
% WavePacket run.

% Number of (coupled) Schr�dinger equations
hamilt.coupling.n_eqs = 1;

% Spatial discretization
space.dof{1} = grid_legendre;            % grid for expansion in Legendre polynomials
space.dof{1}.label = 'cos \Theta';
space.dof{1}.R_0 = 1;                    % constant value for R
space.dof{1}.m_0 = 0;                    % minor quantum number fixed to 0
space.dof{1}.l_max = 200;                % maximum angular momentum/ number of points
space.dof{1}.mass = 0.5;                 % adjusted mass

% cosine^2 projector
space.prj.handle = @prj.cosine;
space.prj.params.exp = 2;


% Hamiltonian operator 
hamilt.eigen.cutoff    = 0.0;            % Cut-off entries of Hamiltonian matrix

hamilt.truncate.min    =  -1e4;          % Lower truncation of energy
hamilt.truncate.max    =  1e4;           % Upper truncation of energy

hamilt.pot.handle      = @pot.harmonic;  % Harmonic oscillator
hamilt.pot.params.v_2  = -80 * 2;        % Force constant
hamilt.pot.params.r_e  = 0.0;            % Equilibrium position

% Select eigen/values/functions
psi.eigen.start        =  0;             % Lower index
psi.eigen.stop         = 15;             % Upper index

% Modify settings for appearance of plots (if desired)
plots.density.type = 'polar';            % polar plot

plots.pot.max = 200;                     % customize density plot
plots.expect.energies.max = 300;         % Set maximum for energy plot
