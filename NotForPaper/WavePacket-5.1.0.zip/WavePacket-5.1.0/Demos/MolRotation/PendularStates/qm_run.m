cd 1;   qm_run;    cd ..;
cd 2;   qm_run;    cd ..;
cd 3;   qm_run;    cd ..;
cd 4;   qm_run;    cd ..;
cd 5;   qm_setup('qm_bound'); qm_init(); qm_bound(); qm_cleanup();   cd ..;
