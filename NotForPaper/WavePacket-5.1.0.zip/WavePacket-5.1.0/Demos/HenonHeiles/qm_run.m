cd Bound_2D;    qm_run;    cd ..;
