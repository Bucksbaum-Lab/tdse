% Plot evolution of input/output of bilinear control problem in 3 subplots:
% (1) input (=control fields), (2) state vector, (3) output (=observables) 
% versus time, with legends

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2011 Boris Schaefer-Bung, Burkhard Schmidt, Ulf Lorenz
%               2012 Jeremy Rodriguez, Burkhard Schmidt, Ulf Lorenz
%
% see the README file for license details.

function plot ( step )

global bilinear plots time control

% Size of problem: Number of components of u, x, y
if isfield (control,'u')
    if isfield (control.u,'t')
        control.u.n = size (control.u.t,1);
    else
        control.u.n = 0;
    end
else
    control.u.n = 0;
end
control.x.n = size (control.x.t,1);
control.y.n = size (control.y.t,1);

control.x.max = 25;

% Get the number of subplots: 2 (no control) or 3 (with control)
numPlots = 2 + (control.u.n > 0);
plotIndex = 1;

%% Initial time step
if step==1
    
    % Initialize figure
    h = figure(8);
    clf;

    plot.logo;
    set(h,'units','pixels', ...
        'position',[plots.control.size.left ...
        plots.control.size.lower ...
        plots.control.size.width ...
        plots.control.size.height] );

    % (1) Input (=control fields) u(t)
    if control.u.n>0
        subplot(numPlots,1,plotIndex);
        plotIndex = plotIndex + 1;

        axis ( [ time.main.start*time.main.delta time.main.stop*time.main.delta ...
            -1.1*max(time.efield.ampli) 1.1*max(time.efield.ampli) ] )
        ylim('auto')
        hold on
        set ( gca, 'LineWidth',     plots.style.line.thick, ...
            'FontName',      plots.style.font.name,  ...
            'FontSize',      plots.style.font.large, ...
            'FontWeight',    plots.style.font.heavy )
        
        xlabel('time')
        ylabel('control field(s) u(t)')
        title([ bilinear.title int2str(control.x.n) ' coupled ODEs'])
        box on
    end
    if control.u.n>1
        control.u.legend = cell(control.u.n,1);
        for i=1:control.u.n
            control.u.legend{i}=int2str(i);
        end
    end

    
    % (2) State vector x(t)
    subplot(numPlots,1,plotIndex);
    plotIndex = plotIndex + 1;
    
    axis ( [ time.main.start*time.main.delta time.main.stop*time.main.delta 0 1] )
    ylim('auto')
    hold on
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    
    xlabel('time')
    ylabel('state |x(t)|')
    if control.u.n==0
        title([ bilinear.title int2str(control.x.n) ' coupled ODEs'])
    end
    box on

    control.x.legend = cell(min(control.x.n,control.x.max),1);
    for i=1:min(control.x.n,control.x.max)
        control.x.legend{i}=int2str(i);
    end
    
    % (3) Output (=observables) y(t)
    subplot (numPlots,1,plotIndex);

    axis ( [ time.main.start*time.main.delta time.main.stop*time.main.delta 0 1] )
    ylim('auto')
    hold on
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    
    xlabel('time')
    ylabel('observable(s) y(t)')
    box on

    
    %% All later time steps
else
    figure(8)
    
    % (1) Plot input (=control fields) u(t)
    if(control.u.n>0)
        subplot (numPlots,1,plotIndex);
        plotIndex = plotIndex + 1;
		cla();

		% Plot the efield only up to the current main time step.
		maxIndex = 1 + (step-1) * time.sub.n;

        for len=1:control.u.n
            plot(time.sub.grid(1:maxIndex),real(control.u.t(len,1:maxIndex)), ...
                'LineStyle', '-', ...
                'LineWidth', plots.style.line.thin, ...
                'Color',     plots.style.colors(len,:))
        end
        if control.u.n>1
            legend(control.u.legend,'Location','NorthEast')
        end
        set ( gca, 'LineWidth',     plots.style.line.thick, ...
            'FontName',      plots.style.font.name,  ...
            'FontSize',      plots.style.font.large, ...
            'FontWeight',    plots.style.font.heavy )
    end

    % (2) Plot state vector x(t)
    subplot (numPlots,1,plotIndex);
    plotIndex = plotIndex + 1;
    cla(); 
    
    for len=1:min(control.x.n,control.x.max) % Plot evolution of x(t)
        plot (time.main.grid(1:step), real(control.x.t(len,1:step)+control.x.e(len)),...
            'LineStyle', '-', ...
            'LineWidth', plots.style.line.thin,...
            'Color',     plots.style.colors(len,:))
    end
    legend(control.x.legend,'Location','NorthEast')
    for len=1:min(control.x.n,control.x.max) % Plot asymptotic x_e
        line([time.main.grid(1) time.main.grid(step)],real(control.x.e(len))*[1 1],...
            'LineStyle', ':', ...
            'LineWidth', plots.style.line.thin,...
            'Color',plots.style.colors(len,:))
    end
    
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    drawnow;
    
    % (3) Plot output (=observables) y(t)
    subplot (numPlots,1,plotIndex);
    cla();

    for len=1:control.y.n % Plot evolution of y(t)
        plot (time.main.grid(1:step), real(control.y.t(len,1:step)),...
            'LineStyle', '-', ...
            'LineWidth', plots.style.line.thin,...
            'Color',plots.style.colors(len,:))
    end
    legend(control.y.legend,'Location','NorthEast')
    for len=1:control.y.n % Plot asymptotic y_e
        line([time.main.grid(1) time.main.grid(step)],real(control.y.e(len))*[1 1],...
            'LineStyle', ':', ...
            'LineWidth', plots.style.line.thin,...
            'Color',plots.style.colors(len,:))
    end
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )

end

%% Finalize
plotIndex = 1;
if step==time.main.n
    figure(8)
    
    % input (=control fields) u(t)
    if control.u.n>0
        subplot (numPlots,1,plotIndex);
        plotIndex = plotIndex + 1;
        hold off
    end
    
    % state vector x(t)
    subplot (numPlots,1,plotIndex);
    plotIndex = plotIndex + 1;
    hold off
    
    % output (=observables) y(t)
    subplot (numPlots,1,plotIndex);
    hold off
    
end
