%--------------------------------------------------------------------------
%
% Create initial state vector for TDSE propagation or
% create initial and thermal (Boltzmann) density matrix for LVNE propagation.
% In the latter case the matrices are vectorized: default is columnwise.
%
% Note that quantum states start counting from zero!
%
% For Boltzmann populations, temperature is in atomic units of 315,923.5 K
%
%--------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2011 Boris Schaefer-Bung, Burkhard Schmidt
%               2012 Jeremy Rodriguez, Ulf Lorenz
%
% see the README file for license details.
 
function init(eom, H0)
global control bilinear

% Size of density matrices
dim=size(H0, 1);

util.disp (' ')
util.disp ('-------------------------------------------------------------')
util.disp (' ')

switch lower(eom)
    
    case 'tdse'
        
        bilinear.initial=zeros(dim,1);
        switch lower (control.initial.choice)
            case 'pure' % pure state
                bilinear.initial(control.initial.pure+1)=1;
                util.disp(['TDSE initial state: pure state = ', int2str(control.initial.pure)])
            case 'cat' % Schroedinger cat state
                bilinear.initial(control.initial.cat(1)+1)=1/sqrt(2);
                bilinear.initial(control.initial.cat(2)+1)=1/sqrt(2);
                util.disp(['TDSE initial state: cat state = ', int2str(control.initial.cat)])
            otherwise
                util.error (['Wrong choice of TDSE initial conditions: ' control.initial.choice])
        end
        
        bilinear.equilib = zeros(dim,1); % chosen to correspond to the zero eigenvalue
        bilinear.equilib(1) = 1;
        util.disp(['TDSE "equilibrium" : ground state'])
        
    case 'lvne'
        
        % Set up initial density matrix
        bilinear.initial = zeros(dim);
        switch lower (control.initial.choice)
            case 'pure' % pure state
                bilinear.initial(control.initial.pure+1,control.initial.pure+1) = 1;
                util.disp(['LvNE initial density: pure state = ', int2str(control.initial.pure)])
            case 'cat' % Schroedinger cat state: coherent superposition
                bilinear.initial = zeros(dim);
                bilinear.initial(control.initial.cat(1)+1,control.initial.cat(1)+1) = 1/2;
                bilinear.initial(control.initial.cat(2)+1,control.initial.cat(2)+1) = 1/2;
                bilinear.initial(control.initial.cat(1)+1,control.initial.cat(2)+1) = 1/2;
                bilinear.initial(control.initial.cat(2)+1,control.initial.cat(1)+1) = 1/2;
                util.disp(['LvNE initial density: cat state = ', int2str(control.initial.cat)])
            case 'mixed' % Incoherent superposition
                bilinear.initial = zeros(dim);
                bilinear.initial(control.initial.mixed(1)+1,control.initial.mixed(1)+1) = 1/2;
                bilinear.initial(control.initial.mixed(2)+1,control.initial.mixed(2)+1) = 1/2;
                util.disp(['LvNE initial density: mixed state = ', int2str(control.initial.mixed)])
            case 'thermal' % thermal (Boltzmann) distribution
                if (control.initial.temperature==0)
                    boltz = zeros(dim,1); % vector
                    boltz(1) = 1;
                else
                    boltz=exp(-H0/control.initial.temperature);
                    boltz=boltz/sum(boltz);
                end
                bilinear.initial=diag(boltz);
                util.disp(['LvNE initial density: thermal with kBT = ', num2str(control.initial.temperature)])
                for n=1:dim
                    util.disp([int2str(n-1) ' : ' num2str(real(boltz(n)))])
                end
            otherwise
                util.error (['Wrong choice of LvNE initial conditions: ' control.initial.choice])
        end
        util.disp(' ')
        
        % Also construct thermal density matrix as fixpoint of matrix A
        if (control.lvne.temperature==0)
            boltz = zeros(dim,1); % vector
            boltz(1) = 1;
        else
            boltz = exp(-H0/control.lvne.temperature); % vector
            boltz = boltz/sum(boltz); % normalize
        end
        bilinear.equilib = diag(boltz); % construct diagonal matrix
        util.disp(['LVNE equilibrium density: thermal with kBT = ', num2str(control.lvne.temperature)])
        for n=1:dim
            util.disp([int2str(n-1) ' : ' num2str(real(boltz(n)))])
        end
        util.disp(' ')
       
        % vectorize initial/thermal density matrices: columnwise ordering
        bilinear.initial=bilinear.initial(:);
        bilinear.equilib=bilinear.equilib(:);
        
        
end

