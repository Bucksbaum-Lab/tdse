% Calculates values of observables
% which can be linear (bilinear.C) and/or quadratic (bilinear.D) 
%
% y = C * x + x * D * x
%
% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2012 Burkhard Schmidt, Jeremy Rodriguez, Ulf Lorenz
%
% see the README file for license details.

function y = observe (step, x)

global bilinear;

%% Only upon first call: get/check number of observables
if step == 1
    
    % Lengths of cell vectors C, D
    bilinear.len.C = 0; if isfield(bilinear,'C'); bilinear.len.C = length(bilinear.C); end
    bilinear.len.D = 0; if isfield(bilinear,'D'); bilinear.len.D = length(bilinear.D); end
    bilinear.len.CD = max(bilinear.len.C,bilinear.len.D);
    
    % Check consistency of lengths of C and D
    if (bilinear.len.C && bilinear.len.D)
        if bilinear.len.C~=bilinear.len.D
            util.error ('cell vectors C and D should be of the same length')
        end
    end
    
    % At least one of C, D should exist
    if ~bilinear.len.CD
        util.error ('either cell vector C or D need to exist')
    end
    
end

%% Calculate the observables from C and/or D
y = zeros (bilinear.len.CD,1);
for l = 1:bilinear.len.CD
    if bilinear.len.C
        y(l) = y(l) +  bilinear.C{l} * x;
    end
    if bilinear.len.D
        y(l) = y(l) + dot(x,bilinear.D{l} * x);
    end
end


end
