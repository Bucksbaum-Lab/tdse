% Plot spectrum of A-matrix
% To be called from qm_abncd.m

function spec_A ()

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2012 Boris Schaefer-Bung, Burkhard Schmidt, Ulf Lorenz
%
% see the README file for license details.

global bilinear plots control

figure(19);
clf;
plot.logo;

if strcmp(control.lvne.order,'df') % Split into densities and coherences
    dim = round(sqrt(real(size(bilinear.A,1))));
    dense = bilinear.A(    1:dim,    1:dim);
    coher = bilinear.A(dim+1:end,dim+1:end);
    spec = eig(full(dense));
    plot(real(diag(dense)),imag(diag(dense)),'or','Markersize',4,'MarkerFaceColor','r');
    hold on
    plot(real(    spec   ),imag(    spec   ),'og','Markersize',4,'MarkerFaceColor','g');
    plot(real(diag(coher)),imag(diag(coher)),'ob','Markersize',4,'MarkerFaceColor','b');
    hold off
    legend ('densities (diag)','densities (eig)','coherences (diag=eig)', 'Location', 'NorthWest')
else
    spec = eig(full(bilinear.A));
    plot(real(spec),imag(spec),'ob','Markersize',4);
    legend ('eigenvalues', 'Location', 'NorthWest')
end
set ( gca, 'LineWidth',     plots.style.line.thick, ...
    'FontName',      plots.style.font.name,  ...
    'FontSize',      plots.style.font.large, ...
    'FontWeight',    plots.style.font.heavy )
xlabel('Real part (from total dephasing rates)')
ylabel('Imaginary part (from energy differences)')
title({'Matrix A: diagonal entries and spectrum';bilinear.title})
