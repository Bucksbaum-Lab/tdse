%--------------------------------------------------------------------------
% Right-hand-side of bilinear control equation:
%
%  d                                               
%  -- x(t) = (A + iNu(t))x(t) +iBu(t)           
%  dt
%
% where A represents the dynamics of the unperturbed system and 
% where u(t) represents external control field(s) interacting through N, B
% 
%--------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2011 Boris Schaefer-Bung, Burkhard Schmidt, Ulf Lorenz
%               2012 Burkhard Schmidt, Jeremy Rodriguez
%
% see the README file for license details.

function x_out = rhs (t, x_in)

global bilinear

% dynamics of the unperturbed system
x_out = bilinear.A*x_in;

% Get external control field
e = util.efield(t);

% interaction with external control fields along x and or y
if length(bilinear.N)>0 
    x_out = x_out + 1i * e.x  * ( bilinear.N{1} * x_in  + bilinear.B{1});
end
if length(bilinear.N)>1
    x_out = x_out + 1i * e.y  * ( bilinear.N{2} * x_in  + bilinear.B{2});
end

