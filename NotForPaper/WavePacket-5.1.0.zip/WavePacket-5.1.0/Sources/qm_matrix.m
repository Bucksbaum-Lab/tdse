%------------------------------------------------------------------------------
%
% Matrix (eigen) representations of important operators
%
% This function takes as input the path to a save file similar to qm_movie.
% It then assumes that each entry in the save file is an eigenstate of some
% Hamiltonian, and calculates the eigenenergies, matrix elements of dipole
% along x and/or y (if applicable) and optionally also matrix elements of 
% the system/bath coupling. All these numbers are combined in structure tise 
% and are written to file "tise.mat" in the current working directory. 
%
% An optional third parameter can be supplied to define a cut-off; dipole
% elements are set to zero if they are smaller than the cut-off, which keeps
% the output files more readable.
%
%------------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2011 Ulf Lorenz, Boris Schaefer-Bung, Burkhard Schmidt
%               2012 Jeremy Rodriguez, Burkhard Schmidt, Ulf Lorenz
%
% see the README file for license details.

function qm_matrix(savedir, savefile, cutoff)

global control hamilt psi space time


util.disp('-------------------------------------------------------------');
util.disp(' Matrix (eigen) representations of important operators       ');
util.disp(' by numerical integration using DVR (quadrature) schemes     ');
util.disp(' https://sourceforge.net/p/wavepacket/matlab/wiki/Reference.Programs.qm_matrix/                                                            ');
util.disp('                                                             ');
util.disp(' Energies: \delta_ij E_i = <i|H|j>                           ')
util.disp('                                                             ');
util.disp(' Dipole moments: d_{ij} = <i|d_x/y|j>                        ')
util.disp('                                                             ');
util.disp(' System-bath coupling: \chi_{ij} = <i|\chi|j>                ')
util.disp('                                                             ');
util.disp(' Populations to be used as control targets                   ')
util.disp('                                                             ');
util.disp(' Reading eigenvectors from                                   ');
util.disp(['           ' savefile]);
util.disp(' residing in directory                                       ');
util.disp(['           ' savedir]);
util.disp('-------------------------------------------------------------');


%% Load the input
context = ket.load(savedir, savefile, true);

%% Preallocate fields (ham, dip, sbc) of structure 'tise' (if applicable)
tise.ham = zeros(time.main.n, 1);

if isfield(hamilt,'d_x') && isfield(hamilt.d_x,'grid_ND')
    tise.d_x = zeros(time.main.n);
end

if isfield(hamilt,'d_y') && isfield(hamilt.d_y,'grid_ND')
    tise.d_y = zeros(time.main.n);
end

if isfield(hamilt,'sbc') && isfield(hamilt.sbc, 'grid_ND')
    tise.sbc = zeros(time.main.n);
end

%% Calculate all matrix elements
for bra_index = 1:time.main.n
	context = ket.load(context, bra_index, true);
	bra_state = psi.dvr.grid_ND;

	% calculate the eigenenergy
	ket.hamilt(0,0,0);
	for m = 1:hamilt.coupling.n_eqs
		tise.ham(bra_index) = tise.ham(bra_index) + sum( ...
            conj(bra_state{m}(:)) .* psi.dvr.new_ND{m}(:).* space.dvr.weight_ND(:));
	end

	% Otherwise, calculate the dipole matrix and the coupling
	for ket_index = 1:time.main.n
		context = ket.load(context, ket_index, true);
		ket_state = psi.dvr.grid_ND;

		if isfield (tise, 'd_x')
            tise.d_x(bra_index, ket_index) = ket.sandwich(bra_state, hamilt.d_x.grid_ND, ket_state);
		end

		if isfield (tise, 'd_y')
            tise.d_y(bra_index, ket_index) = ket.sandwich(bra_state, hamilt.d_y.grid_ND, ket_state);
		end
        
		if isfield (tise, 'sbc')
            tise.sbc(bra_index, ket_index) = ket.sandwich(bra_state, hamilt.sbc.grid_ND, ket_state);
		end
	end
end

%% Optionally truncate matrix elements
if nargin == 3
	if isfield (tise, 'd_x'); tise.d_x(abs(tise.d_x) < cutoff) = 0; end
	if isfield (tise, 'd_y'); tise.d_y(abs(tise.d_y) < cutoff) = 0; end
	if isfield (tise, 'sbc'); tise.sbc(abs(tise.sbc) < cutoff) = 0; end
end

% Populations as observables (to be used in qm_abncd, qm_control)
% To be implemented later: also other observables; smart choice
util.disp ('Populations as observables')
tise.obs=cell(length(control.observables),1);
for n=1:length(control.observables)
    tise.obs{n} = zeros(time.main.n);
    util.disp ([int2str(n) ' = ' control.labels{n} ': ' int2str(control.observables{n})])
    tise.lab{n} = control.labels{n};
    for m=1:length(control.observables{n})
        ii=control.observables{n}(m)+1;
        tise.obs{n}(ii,ii) = 1;
    end
end

%% Save structure 'tise' to disk
util.disp (' ')
util.disp ('Saving all matrix representations in file: tise.mat')
save('tise','tise');

%% Plot matrices

figure(11);
clf;
plot.logo
global plots

% Energy level diagram (diagonal matrix)
subplot(2,2,1)
plot([0:time.main.n-1],real(tise.ham),'o')
set ( gca, 'LineWidth',     plots.style.line.thick, ...
    'FontName',      plots.style.font.name,  ...
    'FontSize',      plots.style.font.large, ...
    'FontWeight',    plots.style.font.heavy )
xlabel('n')
ylabel('E(n)')
title('Energy level diagram')

% System-bath coupling
if isfield (tise, 'sbc');
    subplot(2,2,2)
    surf(tise.sbc)
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    xlabel('n')
    ylabel('m')
    zlabel('C(n,m)')
    title('System-bath coupling')
end

% Dipole moments (x)
if isfield (tise, 'd_x');
    subplot(2,2,3)
    surf(tise.d_x)
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    xlabel('n')
    ylabel('m')
    zlabel('\mu_x(n,m)')
    title('Dipole moments (x)')
end

% Dipole moments (y)
if isfield (tise, 'd_y');
    subplot(2,2,4)
    surf(tise.d_y)
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    xlabel('n')
    ylabel('m')
    zlabel('\mu_y(n,m)')
    title('Dipole moments (y)')
end


end



