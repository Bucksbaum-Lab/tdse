% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2011 Boris Schaefer-Bung
%
% see the README file for license details.

function lin
global hamilt space

util.disp (' ')
util.disp ('*****************************************************')
util.disp ('Linear model function for coupling function          ')
util.disp ('                                                     ')
util.disp ('  chi(r) = chi_0 + kappa * ( r - r_0 )               ')
util.disp ('                                                     ')
util.disp ('*****************************************************')
util.disp ( [ 'Coupling parameter : ' num2str(hamilt.sbc.params.chi_0) ] )
util.disp ( [ 'Slope parameter    : ' num2str(hamilt.sbc.params.kappa) ] )
util.disp ( [ 'Length parameter   : ' num2str(hamilt.sbc.params.r_0) ] )
util.disp (' ')

% Check validity
if space.size.n_dim ~= 1
    util.error ('This coupling function is only for 1 dimension')
end

if hamilt.coupling.n_eqs ~= 1
    util.error ('This coupling function is only for 1 state')
end
    
% Linear function (coupling along x)
hamilt.sbc.grid_ND{1,1} = hamilt.sbc.params.chi_0 + hamilt.sbc.params.kappa ...
    * (space.dvr.grid_ND{1} - hamilt.sbc.params.r_0 );
