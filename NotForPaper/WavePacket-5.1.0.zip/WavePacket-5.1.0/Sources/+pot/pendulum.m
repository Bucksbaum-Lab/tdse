% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2008 Burkhard Schmidt
%
% see the README file for license details.

function pendulum
global hamilt space

util.disp (' ')
util.disp ('*******************************************************')
util.disp ('Potential energy for a pendulum with multiple extrema  ')
util.disp ('                                                       ')
util.disp ('         V0 (              )                           ')
util.disp (' V (R) = -- ( 1 + cos(m*R) )                           ')
util.disp ('         2  (              )                           ')
util.disp ('                                                       ')
util.disp (' with barrier height V0 and multiplicity m             ')
util.disp ('                                                       ')
util.disp ('*******************************************************')
util.disp ( [ 'Barrier height V0 : ' num2str(hamilt.pot.params.barrier) ] )
util.disp ( [ 'Multiplicity m    : ' num2str(hamilt.pot.params.multiple) ] )

% Check validity
if space.size.n_dim ~= 1
    util.error ('This potential only for one dimension')
end

if hamilt.coupling.n_eqs ~= 1
    util.error ('This potential only for single Schr�dinger equation')
end

hamilt.pot.grid_ND{1,1} =  hamilt.pot.params.barrier / 2 ...
    * (1+cos(hamilt.pot.params.multiple*space.dvr.grid_ND{1}));








