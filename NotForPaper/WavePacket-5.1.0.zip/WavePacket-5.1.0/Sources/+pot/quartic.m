% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%
% see the README file for license details.

function quartic
global hamilt space

% provide missing coefficients: default=0
if ~isfield(hamilt.pot.params, 'v_0')
    hamilt.pot.params.v_0=0;
end
if ~isfield(hamilt.pot.params, 'v_1')
    hamilt.pot.params.v_1=0;
end
if ~isfield(hamilt.pot.params, 'v_2')
    hamilt.pot.params.v_2=0;
end
if ~isfield(hamilt.pot.params, 'v_3')
    hamilt.pot.params.v_3=0;
end
if ~isfield(hamilt.pot.params, 'v_4')
    hamilt.pot.params.v_4=0;
end


util.disp (' ')
util.disp ('*******************************************************')
util.disp ('Potential energy: general Quartic polynomial')
util.disp ('*******************************************************')
util.disp ( [ 'Quartic constant : ' num2str(hamilt.pot.params.v_4) ] )
util.disp ( [ 'Cubic constant   : ' num2str(hamilt.pot.params.v_3) ] )
util.disp ( [ 'Force constant   : ' num2str(hamilt.pot.params.v_2) ] )
util.disp ( [ 'Linear constant  : ' num2str(hamilt.pot.params.v_1) ] )
util.disp ( [ 'Shift            : ' num2str(hamilt.pot.params.v_0) ] )
util.disp (' ')

% Check validity
if hamilt.coupling.n_eqs ~= 1
    util.error ('This potential only for single Schr�dinger equation')
end

% Summing up contributions from each component of position vector
hamilt.pot.grid_ND{1,1} = zeros(size(space.dvr.grid_ND{1}));

for k = 1:space.size.n_dim
    hamilt.pot.grid_ND{1,1} = hamilt.pot.grid_ND{1,1} + ...
        hamilt.pot.params.v_4/24 * space.dvr.grid_ND{k}.^4 + ...
        hamilt.pot.params.v_3/6 * space.dvr.grid_ND{k}.^3 + ...
        hamilt.pot.params.v_2/2 * space.dvr.grid_ND{k}.^2 + ...
        hamilt.pot.params.v_1 * space.dvr.grid_ND{k} + ...
        hamilt.pot.params.v_0;
end




