% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%
% see the README file for license details.

function harmonic 
global hamilt space

util.disp (' ')
util.disp ('*******************************************************')
util.disp ('Potential energy: Harmonic oscillator in N dimensions  ')
util.disp ('                                                       ')
util.disp ('          N   k_i             2                        ')
util.disp (' V (R) = Sum  --- ( R  - R0 )                          ')
util.disp ('         i=1   2     i     i                           ')
util.disp ('                                                       ')
util.disp (' with corresponding energy levels E_n = omega*(n+1/2)  ')
util.disp (' with angular frequency omega=sqrt(k/m) for mass m     ')
util.disp (' Note the convenient choice frequently used for        ')
util.disp (' dimensionless coordinates R -> R/sqrt(omega) yielding ')
util.disp (' k=omega  and m=1/omega                                ')
util.disp ('                                                       ')
util.disp ('*******************************************************')
util.disp ( [ 'Force constant k    : ' num2str(hamilt.pot.params.v_2) ] )
util.disp ( [ 'Minimum position R0 : ' num2str(hamilt.pot.params.r_e) ] )

% Check validity
if hamilt.coupling.n_eqs ~= 1
    util.error ('This potential only for single Schr�dinger equation')
end

% Summing up contributions from each component of position vector
hamilt.pot.grid_ND{1,1} = zeros(size(space.dvr.grid_ND{1}));

for k = 1:space.size.n_dim
    hamilt.pot.grid_ND{1,1} = hamilt.pot.grid_ND{1,1} + ...
    (space.dvr.grid_ND{k}-hamilt.pot.params.r_e(k)).^2 * hamilt.pot.params.v_2(k) / 2;
end
