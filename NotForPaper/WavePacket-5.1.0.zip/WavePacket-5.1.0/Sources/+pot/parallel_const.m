% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%
% see the README file for license details.

function parallel_const
global hamilt space

util.disp (' ')
util.disp ('*******************************************************')
util.disp ('Parallel & constant adiabatic potential energy surfaces')
util.disp ('                                                       ')
util.disp ('           ( b*cos^2(cR)-b/2     b*cos(cR)*sin(cR) )   ')
util.disp (' V   (R) = (                                       )   ')
util.disp ('  dia      ( b*cos(cR)*sin(cR)   b*sin^2(cR+a)-b/2 )   ')
util.disp ('                                                       ')
util.disp ('        ( b/2  0  )        ( 0 -c )        ( -c^2  0  )')
util.disp (' E    = (         ),   F = (      ),   G = (          )')
util.disp ('  adi   ( 0  -b/2 )        ( c  0 )        (  0  -c^2 )')
util.disp ('                                                       ')
util.disp (' (C) by George Hagedorn                                ')
util.disp (' Private communication                                 ')
util.disp ('*******************************************************')
util.disp ( [ 'Adiabatic band gap b    : ' num2str(hamilt.pot.params.b) ] )
util.disp ( [ 'Nonadiabatic coupling c : ' num2str(hamilt.pot.params.c) ] )

% Check validity
if hamilt.coupling.n_eqs ~= 2
    util.error ('This potential only for two Schr�dinger equation')
end

if space.size.n_dim ~= 1
    util.error ('This potential only for one dimension')
end

co = cos ( hamilt.pot.params.c*space.dvr.grid_ND{1} );
si = sin ( hamilt.pot.params.c*space.dvr.grid_ND{1} );
hamilt.pot.grid_ND{1,1} = hamilt.pot.params.b * (co.^2-1/2);
hamilt.pot.grid_ND{2,2} = hamilt.pot.params.b * (si.^2-1/2);
hamilt.pot.grid_ND{1,2} = hamilt.pot.params.b * co .* si;








