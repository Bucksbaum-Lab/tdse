%------------------------------------------------------------------------------
%
% Linear potential energy surface
%
%------------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%
% see the README file for license details.

function linear 
global hamilt space

util.disp (' ')
util.disp ('*******************************************************')
util.disp ('Linear potential energy: Ramp with constant slope')
util.disp ('*******************************************************')
util.disp ( [ 'Slope parameter : ' num2str(hamilt.pot.params.slope) ] )

% Check validity
if hamilt.coupling.n_eqs ~= 1
    util.error ('This potential only for single Schr�dinger equation')
end

% Summing up contributions from each component of position vector
hamilt.pot.grid_ND{1,1} = zeros(size(space.dvr.grid_ND{1}));

for k = 1:space.size.n_dim
    hamilt.pot.grid_ND{1,1} = hamilt.pot.grid_ND{1,1} + ...
        hamilt.pot.params.slope(k)*space.dvr.grid_ND{k};
end


