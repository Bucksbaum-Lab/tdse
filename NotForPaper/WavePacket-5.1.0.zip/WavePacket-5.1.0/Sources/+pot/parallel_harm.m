% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%
% see the README file for license details.

function parallel_harm
global hamilt space

util.disp (' ')
util.disp ('*******************************************************')
util.disp ('Potential energy: Harmonic oscillator in N dimensions  ')
util.disp ('                                                       ')
util.disp ('           ( f(R)       C    )                         ')
util.disp (' V   (R) = (                 )                         ')
util.disp ('  dia      (      C     f(R) )                         ')
util.disp ('                                                       ')
util.disp ('                                                       ')
util.disp (' E   (R) = f(R) +/- |C|                                ')
util.disp ('  adi                                                  ')
util.disp ('                                                       ')
util.disp (' Model I : f(R) = k/2 R^2                              ')
util.disp ('                                                       ')
util.disp (' D. Kohen, F.H.Stillinger, J.C.Tully                   ')
util.disp (' J. Chem. Phys. 109(12), 4713 (1998)                   ')
util.disp ('*******************************************************')
util.disp ( [ 'Force constant k      : ' num2str(hamilt.pot.params.v_2) ] )
util.disp ( [ 'Interstate coupling C : ' num2str(hamilt.pot.params.c  ) ] )

% Check validity
if hamilt.coupling.n_eqs ~= 2
    util.error ('This potential only for two Schr�dinger equation')
end

if space.size.n_dim ~= 1
    util.error ('This potential only for one dimension')
end


hamilt.pot.grid_ND{1,1} = space.dvr.grid_ND{1}.^2 * hamilt.pot.params.v_2(1) / 2;
hamilt.pot.grid_ND{2,2} = hamilt.pot.grid_ND{1,1};
hamilt.pot.grid_ND{1,2} = hamilt.pot.params.c * ones(size(space.dvr.grid_ND{1}));
hamilt.pot.grid_ND{1,2} = hamilt.pot.grid_ND{1,2} + 0.5*hamilt.pot.params.c*space.dvr.grid_ND{1};








