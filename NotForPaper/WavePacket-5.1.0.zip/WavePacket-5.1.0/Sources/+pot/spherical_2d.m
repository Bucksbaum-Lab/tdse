%--------------------------------------------------------------------------
% Potential energy function in spherical coordinates R,Theta 
% where the potential does not explicitly depend on Phi and Theta
% 
% Read tabulated values of R-dependent potential energy functions  
% from formatted data file(s) and perform one-dimensional interpolation.
% 
%--------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2007-2008 Ulf Lorenz
%
% see the README file for license details.

function spherical_2d
global hamilt space

util.disp (' ')
util.disp ('*****************************************************')
util.disp ('Interpolation of tabulated values of potential energy')
util.disp ('Special case: H2+ molecule in spherical coordinates')
util.disp ('*****************************************************')
util.disp (['Conversion factor for coordinates : ' num2str(hamilt.pot.params.pos_conv)])
util.disp (['Conversion factor for energies    : ' num2str(hamilt.pot.params.pot_conv)])
util.disp (['Interpolation method              : '         hamilt.pot.params.method])

% Check validity
if space.size.n_dim~=2
    util.error ('Number of dimensions must equal two!')
end

% We expect one of the degrees of freedom to be an FFT one (the radial
% coordinate), the other one should be a Legendre DVR. However, we are not too
% picky about the exact order.
if strcmp(class(space.dof{1}), 'grid_fft')
    Rdof = 1;
    Ldof = 2;
else
    Rdof = 2;
    Ldof = 1;
end

% However, we might wish to be sure that there is exactly one FFT and one
% Legendre DOF
if ~strcmp(class(space.dof{Rdof}), 'grid_fft') || ~strcmp(class(space.dof{Ldof}), 'grid_legendre')
	util.error ('Cannot use spherical potential with this setup of the grid.')
end

% Loop over potential energy tables
for m=1:hamilt.coupling.n_eqs

    % Name of input data file
    filename = strcat('pot', '_', int2str(m), '.dat');
    if hamilt.coupling.n_eqs > 1
        util.disp (['Potential: ' hamilt.coupling.labels{m}])
    else
        util.disp ('Potential: 1')
    end
    
    % Load data from input file
    data = load (filename);
    util.disp(['Loading tabulated data from file : ' filename])

    % Get number of data points
    n = size(data,1); % Number of rows
    util.disp(['Number of data points found      : ' int2str(n)])

    % Extract abscissas and ordinates; convert
    x = data(:,1); x = x / hamilt.pot.params.pos_conv;
    y = data(:,2); y = y / hamilt.pot.params.pot_conv;
    
    % Find min/max
    [c,s] = min ( y );
    [d,t] = max ( y );
    util.disp(['First data pair      : ' num2str(x(1)) ' / ' num2str(y(1),8)])
    util.disp(['Last data pair       : ' num2str(x(n)) ' / ' num2str(y(n),8)])
    util.disp(['Minimum              : ' num2str(x(s)) ' / ' num2str( c  ,8)])
    util.disp(['Maximum              : ' num2str(x(t)) ' / ' num2str( d  ,8)])
    
    % Interpolate
    hamilt.pot.grid_ND{m,m} = interp1( x, y, space.dvr.grid_ND{Rdof}, hamilt.pot.params.method, 'extrap' );
    
end
