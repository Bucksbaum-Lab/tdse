%--------------------------------------------------------------------------
%
% Solves the bilinear control equation using standard ODE solvers
%
% Input variable "filename" typically specifying physical context, e.g.
% 'lvne' for Liouville-von-Neumann
% 'tdse' for time-dependent Schroedinger equation
% Input variable "filenumber" specifying the balancing/truncation scheme
% =0 - unbalanced, untruncated
% =1 - balanced untruncated
% >1 - truncated to this many equations 
%
%--------------------------------------------------------------------------


% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2011 Boris Schaefer-Bung, Ulf Lorenz
%               2012 Burkhard Schmidt, Jeremy Rodriguez, Ulf Lorenz
%
% see the README file for license details.

function qm_control(filename, filenumber)

% Main variables are global throughout;
global bilinear control time  

util.disp (' ')
util.disp ('-------------------------------------------------------------')
util.disp (' Numerical solution of the bilinear control problem          ')
util.disp (' given in terms of the matrices A, B, N and C, D             ')
util.disp (' using ordinary differential equations (ODE) solvers         ')
util.disp (' https://sf.net/p/wavepacket/matlab/wiki/Reference.Programs.qm_control  ')
util.disp ('                                                             ')
util.disp (' d                                                           ')
util.disp (' -- x(t) = ( A + iu(t)N ) x(t) + iu(t)B                      ')
util.disp (' dt                                                          ')
util.disp ('         T        T                                          ')
util.disp (' y(t) = C x(t) + x (t) D x(t)                                ')
util.disp ('                                                             ')
util.disp (' where the input is defined in terms of control field(s) u(t)') 
util.disp (' where the output is defined in terms of observable(s) y(t)  ')
util.disp (' with state vector x = x - x_e (equilibrium) and where the   ')
util.disp (' spectrum of A should be in left half of the complex plane   ')
util.disp (' to ensure stability in the absence of control fields.       ')
util.disp ('-------------------------------------------------------------')
util.disp (' ')

%% Initialize everything

% Initialize temporal discretization
init.timesteps;

% Initialize e-field
init.efield;
time.efield.grid = util.efield(time.sub.grid);
if any(abs(time.efield.grid.x)>0); control.u.t(1,:)=time.efield.grid.x'; end
if any(abs(time.efield.grid.y)>0); control.u.t(2,:)=time.efield.grid.y'; end

% Load A, B, N, and C, D matrices, initial/equilib state/density, etc.
load ([filename '_' int2str(filenumber)]);

util.disp (' ')
util.disp ('*******************************************************')
util.disp ('Propagation: MATLAB (or other) ODE solvers')
util.disp ('*******************************************************')

switch lower(func2str(control.ode.solver))
    case {'ode113', 'ode15s', 'ode23', 'ode23s', 'ode23t', 'ode23tb','ode45'}
        util.disp ( ['ODE solver: ' func2str(control.ode.solver)])
    otherwise
        util.error ( ['Chosen ODE solver ' func2str(control.ode.solver) ...
            ' is not available.'] )
end
util.disp ( ' ' )

options = odeset ('reltol',control.ode.reltol)

% Initial and equilibrium state
control.x.i = bilinear.initial;
control.x.e = bilinear.equilib;

% Labelling the control targets
control.y.legend = bilinear.label;

% Calculating equilibrium output 
control.y.e = oct.observe(1, control.x.e);

% Preallocate x(t), y(t)
control.x.t = zeros(size(bilinear.A,1), time.main.n);
control.y.t = zeros(bilinear.len.CD,    time.main.n);


%% Main loop over time steps
for step = 1:time.main.n
    
    % Initial state: shift by equilibrium state
    if step==1
        control.x.t(:,1) = control.x.i - control.x.e;

    % Propagation by evaluation by chosen ODE solver
    else
        trange = [time.main.grid(step-1) time.main.grid(step)];
        [~,control.x.new] = feval( control.ode.solver, @oct.rhs, trange, control.x.t(:,step-1), options );
        control.x.t(:,step) = control.x.new(end,:).';
    end
    
    % Calculating control targets and correlation measures, and plot
    control.y.t(:,step) = oct.observe(step, control.x.t(:,step)+control.x.e);
    oct.plot ( step );
    
end

% Save time dependence of x-vector
save (['control_' filename '_' int2str(filenumber)],'control','time')

% Output clock/date/time
util.clock;
