%------------------------------------------------------------------------------
%
% Clears the workspace to avoid side-effects from multiple WavePacket runs.
% Also closes/recreates log files etc. Call this function whenever you need a
% fresh workspace.
%
% The input parameter specifies the name under which the following script runs.
% This determines the default name of various output files as well as some
% labels that appear here and there on the plots.
%
% https://sourceforge.net/p/wavepacket/matlab/wiki/Reference.Programs.qm_setup
%
%------------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2007-2009 Ulf Lorenz
%               2008 Burkhard Schmidt
%               2011 Ulf Lorenz, Boris Schaefer-Bung
%               2012 Jeremy Rodriguez, Ulf Lorenz
%    
%
% see the README file for license details.

function qm_setup(scriptname)

% Clear variables/functions and close files (from previous runs);
clear global bilinear balanced correlate control dim_red expect hamilt info plots psi reduced space uncert time
clear functions;
fclose('all');

% Initializes general information and sets up log files.
init.info (scriptname);

% Initialize plotting of densities, expectation values, and spectra
% You do not want to have to set all these parameters by hand
init.plots();
