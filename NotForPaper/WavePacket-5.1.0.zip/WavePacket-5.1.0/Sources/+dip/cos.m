% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2008 Ulf Lorenz
%
% see the README file for license details.


function cos
global hamilt space

util.disp (' ')
util.disp ('*****************************************************')
util.disp ('Permanent dipole moment in spherical coordinates.    ')
util.disp ('                                                     ')
util.disp ('                    2                                ')
util.disp (' mu(Theta) = a * cos  Theta                          ')
util.disp ('*****************************************************')
util.disp (['Polarizability a : ' num2str(hamilt.dip.params.alpha)])

% Check validity
if space.size.n_dim ~= 1 || ~strcmp(class(space.dof{1}), 'grid_legendre')
    util.error ('This dipole function is only for a single Legendre DOF')
end

if hamilt.coupling.n_eqs ~= 1
    util.error ('This dipole function is only for 1 state')
end
    
hamilt.d_x.grid_ND{1,1} = hamilt.dip.params.alpha * space.dvr.grid_ND{1}.^2;
