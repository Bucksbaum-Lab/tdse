%--------------------------------------------------------------------------
% Dipole moment functions in spherical coordinates R, X(==cos theta)
% 
% Read tablulated values of R-dependent dipole moment functions  
% from formatted data file(s) and perform one-dimensional interpolation.  
% Using separate files for parallel(read: x) and perpendicular("y") components!
%
%--------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2007-2008 Ulf Lorenz
%               2008 Burkhard Schmidt
%
% see the README file for license details.

function spherical_2d
global hamilt space

util.disp (' ')
util.disp ('********************************************************')
util.disp ('Interpolation of tabulated values of dipole moments     ')
util.disp ('Special case: diatomic molecule in spherical coordinates')
util.disp ('********************************************************')
util.disp (['Conversion factor for coordinates    : ' num2str(hamilt.dip.params.pos_conv)])
util.disp (['Conversion factor for dipole moments : ' num2str(hamilt.dip.params.dip_conv)])
util.disp (['Interpolation method                 : '         hamilt.dip.params.method])
util.disp (' ')

%% Check validity
if space.size.n_dim~=2
    util.error ('Number of dimensions must equal two!')
end

% We are not really interested if the first or the second degree of freedom is
% the FFT one (i.e., describes the radial motion). However, we require that
% there is one radial and one spherical motion (i.e., Legendre DVR).
if strcmp(class(space.dof{1}),'grid_fft')
    Rdof = 1;
    Ldof = 2;
else
    Rdof = 2;
    Ldof = 1;
end

% Check that the DOF's are really ok.
if ~strcmp(class(space.dof{Rdof}),'grid_fft') || ~strcmp(class(space.dof{Ldof}),'grid_legendre')
    util.error ('Cannot use spherical dipole moments with this setup of the grid.')
end

%% Triple loop over entries of dipole moment matrix (x,y components)

% Some longer explanation for deeper understanding.  The parallel transition
% moments T_par are saved in files "d_x_<from>_<to>", the perpendicular moments
% T_perp in "d_y_<from>_<to>", where from and to are the indices of the surfaces
% (to > from). Theses files are then loaded, interpolated to the values of the
% R coordinate, and the dipole moment in x-direction only (!!! only
% polarisation in x direction is supported) for each point (R_i, X_j) in DVR
% space calculated as T_par(R_i) * cos(theta_i) or Tperp(R_i) * sin(theta_i),
% respectively.
for m=1:hamilt.coupling.n_eqs-1
    for n=m+1:hamilt.coupling.n_eqs
        for p=['x' 'y']

            % Name of input data file
            filename = strcat('d_', p, '_', int2str(m), '_', int2str(n), '.dat');
            util.disp ([p, '-Dipole: ' hamilt.coupling.labels{m},' <--> ',hamilt.coupling.labels{n}])

            % Check availability of input data file
            fid = fopen(filename) ;
            if fid == -1

                util.disp (['Input data file not available : ' filename])
                util.disp ('Leaving entry of dipole matrix empty')
                util.disp (' ')
                
            else

                % Load data from input file
                data = load (filename);
                util.disp(['Loading tabulated data from file : ' filename])
                fclose (fid);
                
                % Get number of data points
                nn = size(data,1); % Number of rows
                util.disp(['Number of data points found      : ' int2str(nn)])

                % Extract abscissas and ordinates; convert
                x = data(:,1); x = x / hamilt.dip.params.pos_conv;
                y = data(:,2); y = y / hamilt.dip.params.dip_conv;

                % Find min/max
                [c,s] = min ( y );
                [d,t] = max ( y );
                util.disp(['First data pair      : ' num2str(x( 1)) ' / ' num2str(y( 1),8)])
                util.disp(['Last data pair       : ' num2str(x(nn)) ' / ' num2str(y(nn),8)])
                util.disp(['Minimum              : ' num2str(x( s)) ' / ' num2str(  c  ,8)])
                util.disp(['Maximum              : ' num2str(x( t)) ' / ' num2str(  d  ,8)])
                
                % Interpolate
                if p=='x' % Parallel
                    util.disp('Parallel polarization')
                    hamilt.d_x.grid_ND{m,n} = interp1( x, y, space.dvr.grid_ND{Rdof}, ...
                        hamilt.pot.params.method, 'extrap' ) .* space.dvr.grid_ND{Ldof};
                elseif p=='y' % Perpendicular
                    util.disp('Perpendicular polarization')
                    hamilt.d_x.grid_ND{m,n} = interp1( x, y, space.dvr.grid_ND{Rdof}, ...
                        hamilt.pot.params.method, 'extrap' ) .* sqrt(1-space.dvr.grid_ND{Ldof}.^2);
                end

            end

            util.disp(' ')

        end
    end
end
