function qm_BTversusH2 (fig,truncate,reduce, switchoff)

%--------------------------------------------------------------------------
%
% Comparison of 'balanced truncation' and/or 'H2 model reduction' versus
% dynamics in full dimensionality. Input vectors "truncate" and/or
% "reduce" contain a variable number of approximation degrees to be
% simulated; if one of those vectors is left empty on input, the 
% respective simulation method will be skipped.
% 
%--------------------------------------------------------------------------


% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2013, 2014 Burkhard Schmidt, FU Berlin

% Initialize: Bound states, matrix elements, full dimensional, balancing
if ~switchoff % Not necessary if energy/dipole matrices from external sources
    qm_setup('qm_bound');   qm_init; qm_bound   ();              qm_cleanup; % not necessary for Stueker data
    qm_setup('qm_matrix');  qm_init; qm_matrix  (pwd,'bound');   qm_cleanup; % not necessary for Stueker data
end

% Control problem in full dimensionality as reference solution
qm_setup('qm_abncd');   qm_init; qm_abncd   ('lvne');        qm_cleanup;
qm_setup('qm_control'); qm_init; qm_control ('lvne',0);      qm_cleanup;
global bilinear control dim_red info plots time
reference = control.y.t;

ndim = size (control.x.t,1);
for j =1:length (bilinear.label)
    mylegend {j,1} = strcat(int2str(ndim), ' (', bilinear.label{j}, ')');
end

% open figure
figure (fig); clf
info.program = 'qm_H2error';
plot.logo;

% Plot figure for BT method
if ~isempty (truncate)
    if ~isempty (reduce) % left half
        subplot(1,2,1)
    end
    hold on
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    for len=1:control.y.n
        plot (time.main.grid,reference(len,:)-reference(len,1),...
            'LineStyle', plots.style.patterns{1}, ...
            'LineWidth', plots.style.line.thin,...
            'Color',plots.style.colors(len,:))
    end
    
    % Balanced truncation
    qm_setup('qm_balance'); qm_init; qm_balance ('lvne'); 
    for k=1:length(truncate)
        
        % Perform truncation and run in reduced dimensionality
        qm_truncate('lvne',truncate(k));
        qm_control('lvne',truncate(k));
        qm_cleanup;
        
        % Plot resulting populations
        figure(fig);
        if ~isempty (reduce) % left half
            subplot(1,2,1)
        end
        global bilinear control dim_red plots time
        for len=1:control.y.n
            plot(time.main.grid,real(control.y.t(len,:)-reference(len,1)),...
                'LineStyle', plots.style.patterns{k+1}, ...
                'LineWidth', plots.style.line.thin,...
                'Color',plots.style.colors(len,:))
        end
        
        for j =1:length (bilinear.label)
            mylegend {control.y.n*k+j,1} = strcat(int2str(truncate(k)), ' (', bilinear.label{j}, ')');
        end
        
    end
    hold off
    legend (mylegend, 'Location','NorthEast', 'FontSize',plots.style.font.small)
    xlabel ('time t')
    ylabel ('observables y(t)-y(0)')
    switch lower(dim_red.Balance.A_stable)
        case 'ssu'
            title  ({'Balanced truncation',['SSU stabilization: ' int2str(dim_red.Balance.A_split) ', B/N scaling: ' num2str(dim_red.Balance.BN_scale)],['ACF couple: ',int2str(dim_red.Balance.acf_couple),', Transform: ',upper(dim_red.Balance.transform),', Truncate: ',dim_red.Balance.truncate]})
        case 'evs'
            title  ({'Balanced truncation',['EVS stabilization: ' num2str(dim_red.Balance.A_shift) ', B/N scaling: ' num2str(dim_red.Balance.BN_scale)],['Transform: ',dim_red.Balance.transform,', Truncate: ',dim_red.Balance.truncate]})
    end
    
end

% Plot figure for H2 method
if ~isempty (reduce)
    figure(fig)
    if ~isempty (truncate) % right half
        subplot(1,2,2)
    end
    hold on
    set ( gca, 'LineWidth',     plots.style.line.thick, ...
        'FontName',      plots.style.font.name,  ...
        'FontSize',      plots.style.font.large, ...
        'FontWeight',    plots.style.font.heavy )
    
    for len=1:control.y.n
        plot (time.main.grid,real(reference(len,:)-reference(len,1)),...
            'LineStyle', plots.style.patterns{1}, ...
            'LineWidth', plots.style.line.thin,...
            'Color',plots.style.colors(len,:))
    end
    
    for k=1:length(reduce)
        
        % Perform dimension reduction and run in reduced dimensionality
        qm_setup('qm_reduce');
        qm_init;
        qm_reduce('lvne',reduce(k));
        qm_control('lvne',reduce(k));
        qm_cleanup;
        
        % Plot resulting populations
        figure(fig);
        if ~isempty (truncate) % right half
            subplot(1,2,2)
        end
        global bilinear control dim_red plots time
        for len=1:control.y.n
            plot(time.main.grid, real(control.y.t(len,:)),...
                'LineStyle', plots.style.patterns{k+1}, ...
                'LineWidth', plots.style.line.thin,...
                'Color',plots.style.colors(len,:))
        end
        
        for j =1:length (bilinear.label)
            mylegend {control.y.n*k+j,1} = strcat(int2str(reduce(k)), ' (', bilinear.label{j}, ')');
        end
        
    end
    hold off
    legend (mylegend, 'Location','NorthEast', 'FontSize',plots.style.font.small)
    xlabel ('time t')
    ylabel ('observables y(t)-y(0)')
    switch lower(dim_red.Reduce.A_stable)
        case 'ssu'
            title  ({'H2 model reduction',['SSU stabilization: ' int2str(dim_red.Reduce.A_split) ', B/N scaling: ' num2str(dim_red.Reduce.BN_scale)],['ACF couple: ',int2str(dim_red.Reduce.acf_couple)]})
         case 'evs'
            title  ({'H2 model reduction',['EVS stabilization: ' num2str(dim_red.Reduce.A_shift) ', B/N scaling: ' num2str(dim_red.Reduce.BN_scale)]})
    end   
end


