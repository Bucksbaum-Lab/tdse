function qm_H2error (fig, truncate ,reduce, switchoff)

%--------------------------------------------------------------------------
%
% Calculated H2error from 'balanced truncation' and/or 'H2 model reduction'
% Input vectors "truncate" and/or "reduce" contain a variable number of 
% approximation degrees to be simulated; if one of those vectors is left 
% empty on input, the respective simulation method will be skipped.
% 
%--------------------------------------------------------------------------


% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2014 Tobias Breiten, TU Graz
% Copyright (C) 2015 Burkhard Schmidt, FU Berlin

% Initialize: Bound states, matrix elements (full dimensionality)
if ~switchoff % Not necessary if energy/dipole matrices from external sources
    qm_setup('qm_bound');   qm_init; qm_bound   ();              qm_cleanup; 
    qm_setup('qm_matrix');  qm_init; qm_matrix  (pwd,'bound');   qm_cleanup; 
end
qm_setup('qm_abncd');   qm_init; qm_abncd   ('lvne');        qm_cleanup;

% Retrieve system matrices (full dimensionality)
global bilinear
A = sparse(bilinear.A);
n = size(A,1);

B = cell(length(bilinear.B),1);
for d=1:length(bilinear.B)
    B{d} = sparse(bilinear.B{d});
end

N = cell(length(bilinear.N),1);
for d=1:length(bilinear.N)
    N{d} = sparse(bilinear.N{d});
end

C = cell(length(bilinear.C),1);
for d=1:length(bilinear.C)
    C{d}=sparse(bilinear.C{d});
end
    
% Balanced truncation
if ~isempty (truncate)
    qm_init; qm_balance ('lvne'); % balancing transformation
    errBT = zeros(length(truncate),1);
    
    % Loop: different truncations
    for k=1:length(truncate)
        qm_setup('qm_truncate'); qm_init; qm_truncate('lvne',truncate(k));
        util.disp('   ')
        util.disp('--------------------------------')
        util.disp('Calculate error norm (BT method)')
        util.disp('--------------------------------')
        util.disp('   ')
        errBT(k) = err(A,B,N,C,n);
    end
end

% H2 model reduction
if ~isempty (reduce)
    errH2 = zeros(length(reduce),1);
    
    % Loop: different reductions
    for k=1:length(reduce)
        qm_setup('qm_reduce'); qm_init; qm_reduce('lvne',reduce(k));
        util.disp('   ')
        util.disp('--------------------------------')
        util.disp('Calculate error norm (H2 method)')
        util.disp('--------------------------------')
        util.disp('   ')
        errH2(k) = err(A,B,N,C,n);
    end    
end

% Initialize figure
global plots info dim_red
figure (fig); clf
info.program = 'qm_H2error';
% plot.logo;
mylegend = {};

% Plot BT result
if ~isempty (truncate)
    semilogy(truncate, real(errBT),'bo-')
    mylegend{length(mylegend)+1} = 'Balanced truncation';
    hold on
end

% Plot H2 result
if ~isempty (reduce)
    semilogy(reduce, real(errH2),'ro-')
    mylegend{length(mylegend)+1} = 'Interpolation based';
end

% General plot settings
legend(mylegend)
set ( gca, 'LineWidth',     plots.style.line.thick, ...
    'FontName',      plots.style.font.name,  ...
    'FontSize',      plots.style.font.large, ...
    'FontWeight',    plots.style.font.heavy )
xlabel (['dimensionality, reduced from ' int2str(n)])
ylabel ( 'H2 error' )
    
title  (['Error system || A shift: ' num2str(dim_red.Error.A_shift) ', B/N scaling: ' num2str(dim_red.Error.BN_scale) ', Glyap: ',dim_red.Error.method])

% Save figure and variables
saveas (gca, int2str(fig), 'fig')
save (int2str(fig))

end

function [H2err] = err (A,B,N,C,n)

% Retrieve system matrices (full dimensionality)
global bilinear dim_red
Ar = sparse(bilinear.A);
r = size(Ar,1);

Br = cell(length(bilinear.B),1);
for d=1:length(bilinear.B)
    Br{d} = sparse(bilinear.B{d});
end

Nr = cell(length(bilinear.N),1);
for d=1:length(bilinear.N)
    Nr{d} = sparse(bilinear.N{d});
end

Cr = cell(length(bilinear.C),1);
for d=1:length(bilinear.C)
    Cr{d}=sparse(bilinear.C{d});
end

% Set up error system
AA = blkdiag(A, Ar);
AA = AA - dim_red.Error.A_shift * speye(n+r); % so far, only EVS implemented

BB = cell(length(B),1);
for d=1:length(B)
    BB{d} = [B{d}; Br{d}]/dim_red.Error.BN_scale;
end

NN = cell(length(N),1);
for d=1:length(N)
    NN{d} = blkdiag(N{d}, Nr{d})/dim_red.Error.BN_scale;
end

CC = cell(length(C),1);
for d=1:length(C)
    CC{d} = [C{d} -Cr{d}];
end

% Solve generalized Lyapunov equation for error system
switch dim_red.Error.method
    case 'iter'
        X = oct.glyap1(AA,BB,NN,false,[]);
    case 'bicg'
        X = oct.glyap2(AA,BB,NN,false,[]);
    otherwise
        util.error (['Wrong choice of GLYAP solver method : ' dim_red.Error.method])
end

% Calculate H2 error
H2err = 0;
for d=1:length(CC)
    H2err = H2err + trace(CC{d}*X*CC{d}');
end
H2err = sqrt(H2err);
util.disp(['H2 error norm = ', num2str(real(H2err))])
util.disp('   ')

end
