clear; clc; close all
 
example = 3;
r = 90;
stability = 'evs';
shift = 1e-6;
max_iter = 100;
tol_bicg = 1e-6;
maxit_bicg = 300;
tol = 1e-3;
K = 1;

switch example
    case 1
        load example1
        u = @(t)  (t<=pi/0.196).*sin(0.196*t)*7.5;
        tsim = linspace(0,50,100);
        gamma = 0.4;
    case 2
        load example2
        u = @(t)  (t<=100).*sin(pi*t/100).^2.*cos(0.196*t)*3.75;
        tsim = linspace(0,100,100);
        gamma = 2;
    otherwise
        load example3
        u = @(t)  (t<=360)*0.2*cos(0.196*t)*sin(pi*t/360)*sin(pi*t/360);
        tsim = linspace(0,800,800);
        gamma = 20;
end
A = sparse(matrix.A);
n = length(A);
N = sparse(matrix.N{1});
B = matrix.B{1};
C = [matrix.C{1};matrix.C{2};matrix.C{3}];

dx_bilinear = @(t,x,A,N,B,u) A*x + 1i*N*x*u(t) + 1i*B*u(t);
dx_bilinear_red = @(t,x,Ar,Nr,Br,u) Ar*x + 1i*Nr*x*u(t) + 1i*Br*u(t);

switch stability
    case 'evs'
        [Ar,Nr,Br,Cr,~,~] = BIRKA_bicg(A-shift*speye(n),N,K,B,C,r,gamma,...
            max_iter,tol,tol_bicg,maxit_bicg);        
    case 'ssu'
        shift = 0;
        tol_eig = 1e-8;
        [V,L] = eig(full(A));
        l = diag(L);
        [~, ind] = sort(l, 'ascend');
        Vs = V(:,ind);
        Ns = Vs\N*Vs;
        Ns = real(Ns).*(abs(real(Ns))>tol_eig) + 1i*imag(Ns).*(abs(imag(Ns))>tol_eig);
        As = Vs\A*Vs;
        As = real(As).*(abs(real(As))>tol_eig) + 1i*imag(As).*(abs(imag(As))>tol_eig);
        Bs = Vs\B;
        Cs = C*Vs;
        Cs = real(Cs).*(abs(real(Cs))>tol_eig) + 1i*imag(Cs).*(abs(imag(Cs))>tol_eig);
        nze = 1; % number of zero eigenvalues
        Nstab = Ns(nze+1:n,nze+1:n);
        Astab = As(nze+1:n,nze+1:n);
        Bstab = Bs(nze+1:n,:);
        Bstab = real(Bstab).*(abs(real(Bstab))>tol_eig) + 1i*imag(Bstab).*(abs(imag(Bstab))>tol_eig);
        Cstab = Cs(:,nze+1:n);
        [~,~,~,~,V,W] = BIRKA_bicg(Astab,Nstab,K,Bstab,Cstab,r,gamma,...
            max_iter,tol,tol_bicg,maxit_bicg);
        
        W = blkdiag(1,inv(W'*V)*W');
        V = blkdiag(1,V);
        
% M�sste man hier nicht eigentlich die SSU transformation 
% (Matrix Vs) wieder r�cgkg�ngig machen ?!?
        
        Ar = W*As*V;
        Nr = W*Ns*V;
        Br = W*Bs;
        Cr = Cs*V;
end
r = size(Ar,1);
[~,x] = ode15s(dx_bilinear,tsim,zeros(n,1),[],A,N,B,u);
y = C*x.';
plot(tsim,real(y(1,:)),'r')
hold on
plot(tsim,real(y(2,:)),'b')
plot(tsim,real(y(3,:)),'g') 
 
[~,xr] = ode15s(dx_bilinear_red,tsim,zeros(r,1),[],Ar+shift*eye(r),...
    gamma*Nr,gamma*Br,u);
yr = Cr*xr.';
plot(tsim,real(yr(1,:)),'r-.')
plot(tsim,real(yr(2,:)),'b-.')
plot(tsim,real(yr(3,:)),'g-.')
