%--------------------------------------------------------------------------
%
% General information: Names of program, user, host, etc
%
%--------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2014 Burkhard Schmidt's group
%               2007-2014 Ulf Lorenz
%
% see the README file for license details.

function info (prog_name)
global info

% Program name and version number
info.package = 'WavePacket';
info.program = prog_name;
info.version = 'V5.1.0';

% Get user name 
result = license('inuse', 'matlab');
info.user_name = result.user;

% Get host name
if isunix 
    [status,result] = unix('hostname');
    if ~status
        info.host_name = strcat(result,' (Unix)');
    else
        info.host_name = 'Running on Unix';
    end
elseif ispc
    [status,result] = dos('hostname');
    if ~status
        info.host_name = strcat(result,' (Windows)');
    else
        info.host_name = 'Running on Windows';
    end
end

    
% Get path and file name 
info.path_name = pwd;
addpath(info.path_name);

% Open log file (or create a new one) for writing in text mode
% Discard existing contents, if any.
filename = fullfile(info.path_name, strcat(info.program, '.log'));
info.stdout = fopen(filename, 'wt');

if info.stdout == -1
    error(strcat('Could not open log file ',filename));
end

% Output program name/version etc
util.disp ( ' ' )
util.disp ( '************************************************************')
util.disp ( ' ' )
util.disp ( strcat('Program package:', info.package) )
util.disp ( strcat('Program name   :', info.program) )
util.disp ( strcat('Version number :', num2str(info.version),' (MATLAB)'))
util.disp ( ' ' )
util.disp ( ' (C) 2004-2015 Burkhard Schmidt, Ulf Lorenz, FU Berlin' )
util.disp ( '     http://sourceforge.net/projects/matlab.wavepacket.p' )
util.disp ( ' ' )
util.disp ( strcat('Path name      :', info.path_name) )
util.disp ( strcat('User name      :', info.user_name) )
util.disp ( strcat('Host name      :', info.host_name) )

% Initialize stopwatch timer; Output clock/date/time
info.start_time = cputime;
util.clock;

% Output GPL info
util.disp ( '************************************************************')
util.disp ( 'This program is subject to the GNU General Public License v2')
util.disp ( 'see http://www.gnu.org or the root path for the license text')
util.disp ( '************************************************************')
util.disp ( ' ' )