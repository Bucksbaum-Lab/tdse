%------------------------------------------------------------------------------
%
% Initial settings of plot parameters
%
%------------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2007-2011 Ulf Lorenz
%               2009 Burkhard Schmidt
%               2012 Ulf Lorenz
%
% see the README file for license details.

function plots
global plots


%%  General appearance of plots 

screen = get (0, 'ScreenSize');          % Screen size
ScreenHeight = screen(4);                % Don't use width for double screens

% If matlab is started from the command line (matlab -nodisplay), the
% above code screws up. In this case, supply a standard value for the
% dimensions. 
if ScreenHeight < 100
	ScreenHeight = 768;
end

% Colors for individual densities/energies: RGB
plots.style.colors = [ 4 0 0 ; ...       % 1: red
                       0 0 4 ; ...       % 2: blue
                       0 4 0 ; ...       % 3: green
                       0 3 3 ; ...       % 4: cyan
                       3 0 3 ; ...       % 5: purple
                       3 3 0 ; ...       % 6: yellow
                       2 2 2 ]/4;        % 7: gray
plots.style.colors = repmat(plots.style.colors,10,1); % repeat 10 times

% Patterns for curves/lines
plots.style.patterns = {'-'; ...         % 1: solid (default) 
                        '--';  ...       % 2: dashed
                        ':'; ...         % 3: dotted
                        '-.'};           % 4: dash-dotted
 
% Lines
plots.style.line.thin  = 1;              % energy contours/curves
plots.style.line.thick = 2;              % axes, density contours/curves
plots.style.line.extrathick = 4;         % polar plots

% Font sizes and weights
plots.style.font.large = round(ScreenHeight/125);
plots.style.font.small = round(ScreenHeight/125)-2;
plots.style.font.heavy = 'bold';         
plots.style.font.light = 'light';        
plots.style.font.name  = 'Helvetica';


%% Plot densities evolving in time

% Factor by which densities are divided before displaying them
plots.dvr.rho_max = [];
plots.fbr.rho_max = [];

% Minimum and maximum ranges to plot potentials
plots.pot.min = [];
plots.pot.max = [];

% Toggle plot
plots.density.on = true;   

% Position and size of plot: Format 9:9
plots.density.size.left   = round(  ScreenHeight/16);     % Left border
plots.density.size.lower  = round(  ScreenHeight/16);     % Lower border
plots.density.size.width  = round(9*ScreenHeight/16);     % Width
plots.density.size.height = round(9*ScreenHeight/16);     % Height

plots.density.size.width =  4*round(plots.density.size.width/4);
plots.density.size.height = 4*round(plots.density.size.height/4);

% Appearence of plot
plots.density.type          = 'contour'; % 'contour' draws a contour plot of WF/Wigner trafo
                                         % 'surface' does the same with a rendered surface
                                         % 'reduced' produces reduced wigner transforms
                                         % 'curve' just draws the 1D wavefunction
                                         % 'polar' makes a polar plot of the 1D wavefunction
plots.density.representation= 'dvr';     % Position (dvr) or momentum (fbr) densities
plots.density.contour.nlev  = [30 15];   % Number of contours: density/energy
plots.density.surface.view  = [60 75];   % View point for surface plot: [az el]
plots.density.surface.look  = [ 1  1];   % Look of surface plot [shading lighting]
plots.density.surface.lite  = [45 45];   % Angle of light for surface plot: [az el]
plots.density.surface.color.on  = false; % manual setting of color ranges
plots.density.surface.color.min = [];    % minimum energy value passed to caxis()
plots.density.surface.color.max = [];    % maximum energy value passed to caxis()
plots.density.expect.on     = false;     % Toggle expectation values 
plots.density.energy.on     = true;      % Toggle energy surfaces
plots.density.marginals.on  = true;      % Toggle marginal function
plots.density.logo.on       = true;      % Logos in all four corners

plots.density.waves.lower   = [];        % Lower contour line for density plots
plots.density.waves.upper   = [];        % Upper contour line for density plots

plots.density.range.on      = false;     % Toggle manual setting of plot range
plots.density.range.x_min   = [];        % Minimum of first coordinate
plots.density.range.x_max   = [];        % Maximum of first coordinate
plots.density.range.y_min   = [];        % Minimum of second/momentum coordinate
plots.density.range.y_max   = [];        % Maximum of second/momentum coordinate

% Export to video file: Currently only mp4-format supported
plots.density.export.on     = true;      % Toggle video export
plots.density.export.file   = [];        % Set the output to a custom filename (w/o suffix)
plots.density.export.images = false;     % Export movie as a series of images


%% Plot expectation values evolving in time
      
% Toggle plot
plots.expect.on = true;   

% Position and size of plot: Format 7:9
plots.expect.size.left   = round(11*ScreenHeight/16);     % Left border
plots.expect.size.lower  = round(01*ScreenHeight/16);     % Lower border
plots.expect.size.width  = round(07*ScreenHeight/16);     % Width
plots.expect.size.height = round(09*ScreenHeight/16);     % Height

% Appearence of plot
plots.expect.population.on  = true;      % Toggle norm plotting
plots.expect.population.min = -0.1;      % Minimum of norm plot
plots.expect.population.max = 1.1;       % Maximum of norm plot
plots.expect.energies.on    = true;      % Toggle exp. value of energies
plots.expect.energies.min   = [];        % Lower bound of the energy plot
plots.expect.energies.max   = [];        % Upper bound of the energy plot
plots.expect.correlation.on = true;      % Toggle autocorrelation
plots.expect.efield.on      = true;      % Toggle electric field
plots.expect.legends.on     = true;      % Toggle legends
plots.expect.logo.on        = true;      % Logos in all four corners

% Export to graphics file: jpg/tiff/epsc/pdf, etc ...
plots.expect.export.on      = false;     % Toggle graphics export    
plots.expect.export.file    = [];        % Set custom filename (suffix determines image type)


%% Plot spectrum (Fourier transform of autocorrelation)
      
% Toggle plot
plots.spectrum.on = false;   

% Position and size of plot 
plots.spectrum.size.left   = round(01  *ScreenHeight/16);     % Left border
plots.spectrum.size.lower  = round(11.5*ScreenHeight/16);     % Lower border
plots.spectrum.size.width  = round(16  *ScreenHeight/16);     % Width
plots.spectrum.size.height = round(03  *ScreenHeight/16);     % Height

% Appearence of plot
plots.spectrum.logo.on     = true;       % Logos in all four corners

% Export to graphics file: jpg/tiff/epsc/pdf, etc ...
plots.spectrum.export.on   = false;      % Toggle graphics export    
plots.spectrum.export.file = [];         % Set custom filename (suffix determines image type)


%% Plot of control input/output/observables
plots.control.size.left   = round(  ScreenHeight/16);     % Left border
plots.control.size.lower  = round(  ScreenHeight/16);     % Lower border
plots.control.size.width  = round(9*ScreenHeight/16);     % Width
plots.control.size.height = round(9*ScreenHeight/16);     % Height
