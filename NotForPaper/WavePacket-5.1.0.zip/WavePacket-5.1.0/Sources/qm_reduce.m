%--------------------------------------------------------------------------
% Solving a generalized Sylvester equation by BIRKA : The bilinear
% Iterative Rational Krylov Algorithm (BIRKA) aims at the construction 
% of bilinear reduced-order models that are (locally) optimal with respect 
% to the bilinear H2-norm. Based on the idea of iterative correction, 
% the algorithm can be seen as a suitable extension of its linear analogue 
% (IRKA). Locally H2-optimal reduced-order models fulfill an abstract 
% Hermite-type interpolation condition for the Volterra series of the 
% bilinear control system. Similar as in the linear case, these optimality 
% conditions can also be stated in terms of (generalized) linear matrix 
% equations. This in turn allows to construct the required projection 
% subspaces as solutions to certain generalized Sylvester equations. 
% 
% max_iter:
% Since BIRKA is an iterative procedure, we need some iteration cycle 
% that should not exceed the number max_iter. For non-converging 
% initialization, max_iter prevents from an infinite iteration cycle. 
% Typical values are max_iter = 50,100,200 (depending on the size of 
% the original model).
%
% conv_tol:
% In numerical computations, the iteration cycle will never yield a 
% convergence tolerance which is exactly 0. We therefore have to specify 
% a value tol which can be seen as a numerical perturbation that we expect 
% not to influence the quality of the computed model significantly.
%
% Interpolation-Based H2-Model Reduction of Bilinear Control Systems;
% Benner, Peter; Breiten, Tobias;
% SIAM Journal on Matrix Analysis and Applications : 
% Vol. 33, No. 3, 859�885; 2012.     doi:10.1137/110836742
%
%--------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2013 Tobias Breiten and Peter Benner, MPI Magdeburg 
%               2014 Burkhard Schmidt, FU Berlin

function qm_reduce(eom, r)

init.info('qm_reduce');

global bilinear dim_red 

util.disp (' ')
util.disp ('--------------------------------------------------------------------------------')
util.disp (' Interpolation based H2 model reduction (c) 2013, Breiten/Benner, MPI Magdeburg ')
util.disp (' Reducing A, B, N, C matrices; also initial/equilibrium state vectors, x_i, x_e ')
util.disp (' http://sourceforge.net/p/wavepacket/matlab/wiki/Reference.Programs.qm_reduce   ');
util.disp ('--------------------------------------------------------------------------------')
util.disp (' ')
util.disp(['reducing to ' int2str(r) ' modes:'])
util.disp (' ')

% Set all parameters to default values if not specified by the user 
if ~isfield (dim_red,'Reduce')
    dim_red.Reduce = [];
end

if ~isfield (dim_red.Reduce,'params')
    dim_red.Reduce.params=[];
end

if ~isfield (dim_red.Reduce,'conv_tol')
    dim_red.Reduce.conv_tol=1e-6;
end
util.disp(['Convergence tolerance for BIRKA iteration: ' num2str(dim_red.Reduce.conv_tol)])

if ~isfield (dim_red.Reduce,'max_iter')
    dim_red.Reduce.max_iter=100;
end
util.disp(['Maximal number of BIRKA iterations: ' int2str(dim_red.Reduce.max_iter)])

if ~isfield (dim_red.Reduce,'method')
    dim_red.Reduce.method='iter';
end
util.disp(['Method for GLYAP solving: ' dim_red.Reduce.method])

if ~isfield(dim_red.Reduce,'BN_scale')
    dim_red.Reduce.BN_scale = 1;
end
util.disp(['Scaling B-vector, N-matrix: ' num2str(dim_red.Reduce.BN_scale)])

% Load full matrices from data file  
% downscale B and N such that generalized Lyapunov equations are solvable
util.disp (['Loading bilinear system matrices from file: ' eom '_0.mat'])
load([eom '_0'])
n = size(bilinear.A,1);
util.disp (['Dimensionality of original system: ' int2str(n)])

A = bilinear.A; 

B = cell(length(bilinear.B),1);
for d=1:length(bilinear.B)
    B{d} = bilinear.B{d} / dim_red.Reduce.BN_scale;
end

N = cell(length(bilinear.N),1);
for d=1:length(bilinear.N)
    N{d} = bilinear.N{d} / dim_red.Reduce.BN_scale;
end

C = cell(length(bilinear.C),1);
for d=1:length(bilinear.C)
    C{d} = bilinear.C{d};
end
util.disp ('   ')

% Check stability: real part of all eigenvalues should be negative
oct.check_stable ('original system matrix A', A)
util.disp (' ')

%% Two choices of stabilizing A matrix
util.disp (' ')
util.disp ('Stabilizing A matrix')
if ~isfield(dim_red.Reduce,'A_stable')
    dim_red.Reduce.A_stable = 'ssu';
end
switch lower(dim_red.Reduce.A_stable)
    case 'ssu' 
        % splitting stable from unstable part i.e. where Re(eig(A)) >= 0
        % consider only the orthogonal complement of zero eigenspace
        % generalization: split all eigenvalues with real part below
        % specified threshold

        util.disp ('Method ''ssu'' : splitting stable from unstable part')
        if ~isfield (dim_red.Reduce,'A_split')
            dim_red.Reduce.A_split = 1;
        end
        n1 = dim_red.Reduce.A_split; 
        util.disp (['Dimension of unstable part : ',int2str(n1)])
        util.disp (' ')
        
        % Calculate all eigenvalues and eigenvectors (columns of U) of A.
        % In general (T>0, with decoherence), A is complex & non-symmetric
        [U,D] = eig(full(A));
        [~, ind] = sort(real(diag(D)), 'descend');
        U = U(:,ind);
                         
        % Transformation and splitting of A, B, N, C into eigenvector basis
        A  = U\A*U;             % transformation
        A  = util.sparse(A);    % reinforce sparsity of A
        Au = A(n1+1:n,   1:n1); % unstable part
        A  = A(n1+1:n,n1+1:n ); % stable part
        
        for d=1:length(B)
            B{d} = U\B{d};       % transformation
            B{d} = B{d}(n1+1:n); % stable part
        end
         
        Nu = cell(length(N),1);
        for d=1:length(N) 
            N{d}  = U\N{d}*U;             % transformation
            N{d}  = util.sparse(N{d});    % reinforce sparsity of A
            Nu{d} = N{d}(n1+1:n,   1:n1); % unstable part
            N{d}  = N{d}(n1+1:n,n1+1:n ); % stable part
        end
        
        for d=1:length(C)
            C{d} = C{d}*U;       % transformation
            C{d} = C{d}(n1+1:n); % stable part 
        end
        
        % Rho coupling terms act as additional control field
        % Does it really make things any better?
        if ~isfield (dim_red.Reduce,'acf_couple')
           dim_red.Reduce.acf_couple=0; 
        end
        if dim_red.Reduce.acf_couple
            nBg = length(B);
            B{nBg+1} = Au;
            for d=1:length(N) 
                B{nBg+1+d} = Nu{d};
            end
        end
        
    case 'evs' 
        util.disp('Method ''evs'': eigenvalue shift of A')
        
        % value of shift
        if ~isfield(dim_red.Reduce,'A_shift')
            dim_red.Reduce.A_shift = 1e-6;
        end
        util.disp (['Value of shift : ' num2str(dim_red.Reduce.A_shift)])
        util.disp (' ')
        
        % shift diagonal values of A-matrix
        A = A - dim_red.Reduce.A_shift * speye(n);
                
    otherwise
        util.error (['Wrong choice of stabilization method : ' dim_red.Reduce.A_stable])
        
end

% Check stability of the splitted (SSU) or shifted (EVS) system
switch lower(dim_red.Balance.A_stable)
    case 'ssu' 
        oct.check_stable ('splitted system matrix A', A)
    case 'evs' 
        oct.check_stable ('shifted system matrix A', A)
end
util.disp (' ')

% Initialization parameters for the iteration cycle. 
% As long as a reasonable reduced-order model is not known, 
% one might just as well use a random initialization
rng('default'); % set random number generator as if you restarted MATLAB
                   Ar    = rand(r);       % full matrix
for d=1:length(B); Br{d} = rand(r,1); end % column vector(s)
for d=1:length(N); Nr{d} = rand(r);   end % full matrix(s)
for d=1:length(C); Cr{d} = rand(1,r); end % row vector(s)

%% Start BIRKA iteration loop
Spec = eig(Ar);
Spec = -sort(Spec);
err = inf;
iter = 0;
while(err > dim_red.Reduce.conv_tol && iter < dim_red.Reduce.max_iter)
    Spec_old = Spec;
    
    % Solve generalized Sylvester equations
    switch lower (dim_red.Reduce.method)
        case 'iter'
            X = oct.gsylv1(A,B,N,Ar,Br,Nr,false,dim_red.Reduce.params);
            Y = oct.gsylv1(A,C,N,Ar,Cr,Nr,true ,dim_red.Reduce.params);
        case 'bicg'
            X = oct.gsylv2(A,B,N,Ar,Br,Nr,false,dim_red.Reduce.params);
            Y = oct.gsylv2(A,C,N,Ar,Cr,Nr,true ,dim_red.Reduce.params);
        otherwise
            util.error (['Wrong choice of GSYLV solver method : ' dim_red.Reduce.method])    
    end
    
    % Orthogonal-triangular decomposition A = Q * R where A is m-by-n
    % where Q is m-by-m (unitary matrix Q)
    % where R is m-by-n (upper triangular matrix)
    [V,~] = qr(X,0);
    [W,~] = qr(Y,0);
    
    % Refining reduced matrices
    S = (W'*V)\W';
                       Ar    = S*A   *V;
    for d=1:length(B); Br{d} = S*B{d}  ; end
    for d=1:length(N); Nr{d} = S*N{d}*V; end
    for d=1:length(C); Cr{d} =   C{d}*V; end
    
    % Spectrum of A
    Spec = eig(Ar);
    Spec = -sort(Spec);
    iter = iter + 1;
    
    % Check change in spectrum of A for convergence
    err = norm(Spec-Spec_old)/norm(Spec_old);
    util.disp([int2str(iter) '-th BIRKA step: conv. crit. = ' num2str(err)])
    
end

%% Add extra columns, rows to S, V matrices to compensate for the SSU splitting
if strcmpi(dim_red.Reduce.A_stable,'ssu')
    S=[zeros(r,n1) S];
    S=S/U;
    V=[zeros(n1,r); V];
    V=U*V; 
end

% Constructing reduced matrices
                            reduced.A    = S*bilinear.A   *V;
oct.check_stable ('reduced system matrix A', reduced.A)
for d=1:length(bilinear.B); reduced.B{d} = S*bilinear.B{d}  ; end % Beware the acf_couple
for d=1:length(bilinear.N); reduced.N{d} = S*bilinear.N{d}*V; end
for d=1:length(bilinear.C); reduced.C{d} =   bilinear.C{d}*V; end

% Reduced state vectors; perhaps to be replaced by: x0r = (W'*V)\(W'*x0)  ?!?
reduced.initial = zeros(r,1);
reduced.equilib = zeros(r,1);

% Scaling factor; labels; titles
reduced.label=bilinear.label;  % labels of control targets
reduced.title=[bilinear.title 'reduced to ']; % simulation title

% Save reduced matrices to data file
clear global bilinear
global bilinear
bilinear = reduced;
util.disp(['Saving reduced matrices A, B, N, C and densities to file : ' eom '_' int2str(r) '.mat'])
save([eom '_' int2str(r)],'bilinear');

