%------------------------------------------------------------------------------
%
% Truncate A, B, N, C and initial/equililibrium state vectors
%
% Upon balancing transformation, the obtained Hankel singular values (HSVs)
% indicate controllability and observability. *Normal* tuncation simply 
% eliminates the low HSV modes because they are weakly controllable and
% weakly observable at the same time. *Confinement* truncation is based
% on the analogy between large HSV-modes with slow dof's and low HSV-modes
% with fast dof's. Then an averaging principle (singular perturbation theory)
% can be used to derive equations of motion for the former one, where the 
% latter one is confined to its average, or rather, the t --> oo limit.  
%
% A = A11 - A12 A22 \ A21
% N = A11 - N12 A22 \ A21
% C = C1  - C2  A22 \ A21
%
% From both an execution time and numerical accuracy standpoint, it is better
% to use Matlab's matrix division operator mldivide (A22\...) than inv(A22)
%
% C. Hartmann, B. Schaefer-Bung, A. Th�ns-Zueva
% SIAM J. Control Optim., 51(3), 2356-2378 (2013)
% doi:10.1137/100796844
% 
% C. Hartmann, V. Vulcanov, Ch. Sch�tte
% Multiscale Model. Simul., 8(4), 1348-1367 (2010)
% doi:10.1137/080732717
% 
%------------------------------------------------------------------------------

% This file is part of the WavePacket program package for quantum-mechanical
% simulations, and subject to the GNU General Public license v. 2 or later.
%
% Copyright (C) 2011 Boris Schaefer-Bung
% Copyright (C) 2012 Burkhard Schmidt
%
% see the README file for license details.
% 

function qm_truncate (eom , trunc)

init.info('qm_truncate');

global  balanced bilinear dim_red

% Load full matrices (already balanced) from data file
load ([eom '_1']);

util.disp (' ')
util.disp ('-------------------------------------------------------------')
util.disp (' Truncating A, B, N, C matrices; also x_i, x_e state vectors ')
util.disp (' http://sourceforge.net/p/wavepacket/matlab/wiki/Reference.Programs.qm_truncate');
util.disp ('-------------------------------------------------------------')
util.disp (' ')
util.disp(['truncating to ' int2str(trunc) ' modes:'])

nbal=size(balanced.A,1);

% Set default values
if ~isfield (dim_red,'Truncate')
    dim_red.Truncate = [];
end
if ~isfield (dim_red.Balance,'truncate')
    dim_red.Balance.truncate = 'normal';
end

% Confinement truncation for A, N, C
switch lower(dim_red.Balance.truncate)
    case 'confine'
        
        util.disp('confinement limited truncation')
        bilinear.A=balanced.A(1:trunc,1:trunc)...            % A11
            - balanced.A(1:trunc,trunc+1:nbal)* ...          % A12
            ((balanced.A(trunc+1:nbal,trunc+1:nbal))...      % A22^(-1)
            \balanced.A(trunc+1:nbal,1:trunc));              % A21
        for d=1:length(balanced.N)
            bilinear.N{d}=balanced.N{d}(1:trunc,1:trunc)...  % N11
                -balanced.N{d}(1:trunc,trunc+1:nbal)*...     % N12
                ((balanced.A(trunc+1:nbal,trunc+1:nbal))...  % A22^(-1)
                \balanced.A(trunc+1:nbal,1:trunc));          % A21
        end
        for d=1:length(balanced.C)
            bilinear.C{d}=balanced.C{d}(1:trunc)...          % C1
                -balanced.C{d}(trunc+1:nbal)* ...            % C2
                ((balanced.A(trunc+1:nbal,trunc+1:nbal))...  % A22^(-1)
                \balanced.A(trunc+1:nbal,1:trunc));          % A21
        end
        
        % normal truncation  for A, N, C
    case 'normal'
        
        util.disp('normal truncation')
        bilinear.A=balanced.A(1:trunc,1:trunc);
        for d=1:length(balanced.N)
            bilinear.N{d}=balanced.N{d}(1:trunc,1:trunc);
        end
        for d=1:length(balanced.C)
            bilinear.C{d}=balanced.C{d}(1:trunc);
        end
        
    otherwise
        util_error (['Invalid choice of truncation method : ' dim_red.Balance.truncate])
end

oct.check_stable ('truncated system matrix A', bilinear.A)

% truncate B matrices
for d=1:length(balanced.B)
    bilinear.B{d}=balanced.B{d}(1:trunc,:);
end

% truncate state vectors (initial and equil) and transformation matrix
bilinear.initial=balanced.initial(1:trunc,:);
bilinear.equilib=balanced.equilib(1:trunc,:);
bilinear.S=balanced.S(1:trunc,:); % needed for qm_correlate ==> oct.reconstruct
bilinear.T=balanced.T(:,1:trunc); % needed for qm_correlate ==> oct.reconstruct

% Save truncated matrices to data file
bilinear.label=balanced.label; % labels of control targets
bilinear.title=[balanced.title 'truncated to '];
util.disp(['Saving truncated matrices A, B, N, C and densities to file : ' eom '_' int2str(trunc) '.mat'])
save ([eom '_' int2str(trunc)], 'bilinear')

end

